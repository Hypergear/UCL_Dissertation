# Declaration {#declaration .unnumbered}

I, Zhiheng Jiang, hereby declare that this dissertation is all my own
original work and that all sources have been acknowledged. It is 10968
words in length.

**Accompanying GitHub repository:
<https://github.com/Hypergear/UCL_Dissertation>**
