::: titlepage
::: center
**Cornerstone of global communication:\
Vulnerabilities of submarine telecommunication cable from networks\
**

by\

**Zhiheng Jiang\
** **Supervisor: Dr. Sarah Wise\
** **Module ID: CASA0012\
** **Word count: 10968\
** **Aug 2022**

**A Dissertation submitted in part fulfilment of the\
Degree of Master of Science:\
Spatial Data Science and Visualisation\
Centre for Advanced Spatial Analysis\
Bartlett Faculty of the Build Environment\
University College London\
**
:::
:::

# Declaration {#declaration .unnumbered}

I, Zhiheng Jiang, hereby declare that this dissertation is all my own
original work and that all sources have been acknowledged. It is 10968
words in length.

**Accompanying GitHub repository:
<https://github.com/Hypergear/UCL_Dissertation>**

# Abstract {#abstract .unnumbered}

With the rise of global internet connectivity and the increasing
availability of inexpensive computer devices. The submarine
telecommunication cables (STC) play as the backbone infrastructure to
provide the data traffic in the case of international information
transmission. However, STC is extremely vulnerable to damages such as
natural disasters and human-led attacks. If the damage is taken, the
bandwidth deterioration or lagging of the internet services will occur
on end-users' computers. At the core of this paper is a modelling
analysis of the global STC under a topological network structure to
determine the subregional high risk area. As the result, 88 STC
vulnerable countries and an uneven distribution of network dependency
can be located. For a regional STC network system, we proposed a method
to improve and analyze its topological robustness. These findings may
provide some inspiration to the industry and politicians by revisiting
the reliability and vulnerabilities of the STC system under the current
protection measurements.\

**Keywords:** Internet, Telecommunication, Marine infrastructure,
Network science.

# Acknowledgement {#acknowledgement .unnumbered}

I would like to thank my supervisor, Dr. Sarah Wise for her patient
guidance throughout the research lifecycle. Her engaged feedbacks and
inspirational research perspectives were not only valuable to this
project, but also improved my level of thinking both academically and
personally. This paper would not be possible without her enthusiastic
support.

This work has also gained vast support from the a various opensource
communities, regardless of open datasets from TeleGeography or python
packages such as NetworkX. Also the useful studies from the research
community. Their humble work makes this research possible.

I am also grateful for the support from my parents and my corgi - Julie,
who have continuously motivated me throughout this study.

# Acronyms {#acronyms .unnumbered}

There are some frequent used acronyms for certain items/technologies.

**STC** -- Submarine telecommunication cable

**TTC** -- Terrestrial telecommunication cable

**CLS** -- Cable landing station

**CDN** -- Content delivery network

**CIP** -- Critical infrastructure protection

**ISP** -- Internet services provider

# Jargon {#jargon .unnumbered}

If you are new to telecommunication industry, learning these jargons
before proceeding is highly recommended

**Bandwidth** -- The maximum amount of data transmitted over an internet
connection in a given amount of time

**Routing** -- A process of path selection while transferring data
across multiple network systems.

**Capacity** -- Default referring to potential capacity, the total
amount of design capacity that installed all available equipment at the
ends of the cable.

**Lit capacity** -- The amount of capacity that is actually running over
a cable.

# Introduction {#sec:Introduction}

Motivated by the progress of information technology on mobile devices
combined with the rise of the 5G technology and cloud computing
services, the demand for higher stand internet services can be foreseen.
The world needs a medium to transmit a large amount of data
inexpensively more than ever. As the *highway* of data communication,
the optic fibre is the most common tool for wired long-distance data
communication.[@kangovi_2017_3] There are two types of state level fiber
optic cables: fibre optic terrestrial telecommunication cable(TTC) and
fibre optic submarine telecommunication cable(STC). In terms of
useability, the latter gains a bigger market share.
[@marra_2018_ultrastable] Nowadays, STC is responsible for more than 98%
of global internet transmission, reaching approximately more than km
globally.[@winseck_2017_the; @wang_2019_costeffective] In some terms,
any internet service depends on STC's functional working, in fields such
as academia, education, entertainment, finance, health care, and the
military.

STC is already a irreplaceable resources in all aspects of people's
daily life, the failure could cause a significant negative impact on the
social and economic disruptions in a community or society. The failure
of an STC might not disrupt access to the worldwide internet, as the
nature of the internet routing topology, [@calvert_1997_modeling]
suggested that the connection can still be obtained by a longer and less
stable connection. [@turner_2010_california]. However, this is not true
for all countries. In 2008 a dragging ship anchor damaged one or
more STCs in the Mediterranean which subsequently caused 50% to 100% of
internet service interruptions across the middle-east
area. [@zetter_2008_undersea] More recently, in 2022 the volcano
eruption in Tonga caused the failure of Tonga's only STC, which
subsequently led to an internet blackout with the rest of the world for
nearly five weeks. [@bateman_2022_cut] Due to the commercial interest
and limited internet usage, usually less developed countries and remote
islands such as Chile or the Marshall island do not have an alternative
STC for redundancy. [@domineyhowes_2022_when] Obviously, these countries
are more dependent and suffer more losses if the STC breaks down.

Even though STC is a world spread infrastructure, there are still four
billion people who do not have access to the internet. Satellite
internet, on the other hand, can be used to replace the STC by using a
group of non-synchronous orbit satellites. [@graydon_2019_connecting]
These satellites rotate around the earth obit, providing wireless
internet connection to the customer near the earth's surface. If the
satellite is located in geostationary earth orbit, the user will suffer
from high latency and limited bandwidth. Again, they acquires hundreds
of thousands of satellites to provide worldwide coverage which gives
higher standards on the internet services provider(ISP).
[@deutschmann_2021_broadband] Regardless, satellite internet services
always have higher requirements on the user budget than STC, as the
professional technical devices and expensive data packages need to be
pre-purchased before usage. [@starlink_2022_starlink]

The rest of paper is organized as follows. Firstly, in Section
[2](#sec:LitReview){reference-type="ref" reference="sec:LitReview"}, the
vulnerability, legal protections and consequences of STC breakdown are
introduced in details. Then, the related datasets and data pre-process
are provided in Section [3](#sec:Data){reference-type="ref"
reference="sec:Data"}. After that, the analysis procedures including a
local STC optimization approach are given in Section
[4](#sec:Methods){reference-type="ref" reference="sec:Methods"} and
[5](#sec:Results){reference-type="ref" reference="sec:Results"}.
Finally, Section [6](#sec:Disscussion){reference-type="ref"
reference="sec:Disscussion"} and
[7](#sec:Conclusion){reference-type="ref" reference="sec:Conclusion"}
give the discussion and conclusions.

# Literature Review {#sec:LitReview}

The United Nations Office defines the term Critical infrastructure for
Disaster Risk Reduction (USDRR) as *\"The physical structures,
facilities, networks and other assets which provide services that are
essential to the social and economic functioning of a community or
society.\"* [@usdrr_2022_critical] To the importance of the STC, in
1998, US presidential directive PDD-63, also known as Critical
infrastructure protection(CIP) aims to protect *\"..the assets, systems,
and networks, whether physical or virtual, so vital to the United States
that their incapacitation or destruction would have a debilitating
effect on security, national economic security, national public health
or safety, or any combination thereof.\"* [@mccue_2015_chapter] As the
backbone of network communication, STC is ineluctably one of the items
within.

In contrast to the importance of the STC in the real world, the research
attention on STC vulnerabilities remains limited. This work will discuss
three fields of literature: distance from relative infrastructure,
factors that lead to the STC failure, regulations and international law
applied to STC, and the digital divide under STC framework.

## Existing studies of infrastructure resilience

Robustness analysis of essential infrastructure (eg. gas, electricity,
communication) networks has been widely explored in the literature, but
the impact of STC failure has been addressed by only few authors.
[@6153088; @SANG2022100101; @ouyang2015resilience] A robust system is
characterized by its ability to resist, tolerate, absorb, and recover
services under various unfavorable occurrences. [@holling1973resilience]
The infrastructure resilience analysis approaches in the previous
literature include fault tolerant assessment [@santos2005ftweb], network
science analysis [@ulusan2018restoration], simulation method
[@satumtira2010synthesis], surrogate measure [@shin2018systematic] and
others.  Each classification is a well-established research angle to
quantify the resilience of the infrastructure. But no applications on a
global scale. For the STC vulnerabilities, these analyses are carried
out at the level of a country or a region, rather than a global system.
STC is a special case because of the scale of its challenges in
maintenance. Next I will discuss some of these in terms of their
relevance to other infrastructure systems.

Using the complex networks theory, [@HU2020125434] examined the
structural distribution of the US electricity grid by modeling the
electricity market across the 50 states. Utilizing an undirected graph
as the scaffolding, Jun and his colleagues investigated the network
features from 4 data properties and successfully identified an uneven
distribution of the US power market in power generation and the sale
side. Take another example from the liquefied natural gas network,
[@CLEGG2019191] topologically measures the liquefied natural gas
infrastructure resilience in UK under the network science framework. The
paper quantifies the liquefied natural gas network to assess the energy
security of the UK, during climate emergency events during the winter.
Adopting more hybrid heating technologies, allowing a more flexible
switch between gas and electric heating will result in lower gas price
spikes and overall gas network resilience while facing the short-term
supply shock in a real-world emergency.

## Factors that lead to STC failure

The current real-world challenges STC remains on two perspectives: The
first major damage source can be caused by natural hazard or animal
incursion; the second category will focus on human-lead destructions,
whether accidental or intentional. Protecting the fragile fibre twist
pair within the STC is the top priority, STC is divided into five
different protection classes to overcome the different working
conditions and budget balance.
[@allawati_2015_balancing; @libert_2016_13; @ztt_2019_submarine]

### Natural

Considering the cost of assembly and the importance of the network
connectivity, the STC is designed to achieve high reliability of 25
years of service life without any maintenance. [@worthington_1984_cable]
STCs are laid on the seabed where the depth could reach up to 8000m
under the condition of high water pressure, rough rocks combined with
marine corrosion to the STC's protective layer.
[@beaufils_2000_how; @laque_1975_marine] Burying into the seabed is the
most common way to mitigate the chance of cable failure from external
aggressions.

#### Natural hazard

During the cable installations, the deployment crew will try to avoid
seamounts, the exposed cable could be damaged by chafing against the
seabed or steep terrain. In addition to that exposed cables are more
likely to suffer from undersea turbulence by overstretching the cable or
applying impact force while colliding with the adjacent rocks.
[@carter2014submarine] Just like any other terrestrial infrastructure
network, earthquakes, volcanic eruptions, and landslides are also
believed to be potent natural hazards for STC. [@pope_2017_which]
Earthquakes can cause significant movement of the sediments, which might
subsequently break off the cable from the landslides on the seabed.
[@hughes_2015_effect] Volcanic eruptions produce hot lava flow and steam
with the spread of rock fragments which can cause damage to both
exposed/unexposed STC in any term. [@mcdonald_2017_the] But some believe
that volcano eruptions are not the primary cause of the cable breaking,
in both Indonesia's Anak Krakatau volcano in 2018 and Tonga's submarine
volcano eruption in 2022, there was a time difference(around an hour)
between internet traffic dropping and entirely going offline
[@duckett_2022_volcanic; @grilli2019modelling] This could potentially
mean the volcano eruption still remains partially functional after the
largest eruption, revealing the origin of the cable failure comes from
other geotectonic movements such as submarine landslide; submarine
earthquake or even tsunami. [@latter_1981_tsunamis]

If the cable failure was the result of landslides, the actual repairing
crew might suffer from a range of issues, from overturning ocean
circulation to locating the ends of damaged cables, which would result
in delays in repairing progress. In the case of Tonga 2022, the repair
vessel *CS Reliance* did not prepare enough cables aboard because the
broken cables were moved more than 80 km due to the landslide or
shockwaves. [@needham_2022_tonga]

#### Animal

The engineers in the cable design crew tend to use the cable with
stronger armor protection when the STC reaches a very shallowed water
zone(less than 50m depth) or regions where the cable is not suitable to
be buried under the seabed, such as rocky outcrops, animal habitats or
fishing harbours where intensive external aggression could apply to the
STC. Moreover, more than 90% of marine life and erosion of sharp broken
rocks by turbulent flow further evaluated the threat to the cables. The
majority of marine animals show no harm to the STC, but many historical
records show sharks(especially the Carcharhinid shark family) are
particularly interested in attacking STCs. This action is also known as
sharkbite [@29600] some research suggests that the electromagnetic
fields or acoustic vibrations generated by the cable combined with the
aggressive, curious personality attract the shark's attention from
\"fish biting\". [@eichengreen_2016_cables; @west2014shark]

### Human

The world submarine network did not experience global disruptions thanks
to the network rerouting, increasing supply of cable ships(A specialized
ship to install and repair the STC) and fast-growing cable breakdown
detection technology in recent decades. [@inc_2020_submarine] This
section will discuss the STC disfunction due to human activities.

#### Accidental

There are about 150-200 STC failure cases annually, the marine
activities such as fishing dredges and anchoring are the two primary
reasons causing the damage to the STC, around 72% of failures are
directly caused by these. [@Kordahi2016GLOBALTI] Furthermore, the
failures caused by fishing and anchoring are more likely to happen in
the shallow water, the chance decreases as the water gets deeper
[@mamatsopoulos_2020_critical] The fishing dredge is towed along the
seabed to harvest the species at the bottom of the ocean. This action
can directly cause damage to unburied STC [@carter_2010_submarine] When
anchoring the ship, there are two types of damage that can occur:
dragging damage and impact damage. Fig
[2.1](#fig:literature_img_anchoring){reference-type="ref"
reference="fig:literature_img_anchoring"}

![Impact and drag damage on STC by anchoring
[@zheng_2022_study]](Img/literature_img_anchoring.png){#fig:literature_img_anchoring
width="5.7in"}

#### Intentional

Considering the role of intelligence in strategic and tactical judgments
during armed conflicts, disrupting the source of intelligence is linked
to the outcome of the military operation. [@gentry_2019_intelligence]
The first offensive cable cutting can be traced back to WWI, one of the
very first orders after the war declaration between Britain and Germany
was to destroy Germany's STC in the English channel. The remaining
cables were also under the surveillance of the code breaker team \"Room
40\" in London. [@bruton_2017_the] Resulting of the counterattack of
*SMS Emden*(a german navy cruiser) destroyed a British cable landing
station at Tabuaeran. [@kennedy_1971_imperial]

STC attacks include, but are not limited to, total breakdown, temporary
disablement, interference, and disruptions. These faults could cause
delays or loss of data packages on a particular cable, even if the
global capacity is overloaded. [@gentry_2019_intelligence] Modern
intentional attacks apply to physical failures in the system
infrastructure and failures of the network to carry traffic as a result
of cyberattacks.

Any approach threatening STC caused by kinetic impact is included in
this area. The target facilities could either be the STC itself or the
landing station on land.

-   At the sea: Similar to any marine law on the high sea, the lack of
    information sharing and the ability of monitorization on thousands
    of miles long STC dramatically lower the difficulty when malicious
    people are trying to attack cables. [@lindsay_2015_the] In addition
    to that, some specialized equipment(e.g. submarines and diving
    suits) provides more options to cause damage. In 2013, the Egyptian
    Navy caught three hackers on a fishing boat near the city of
    Alexandria who were attempting to cut the SEA-ME-WE 4 cable by
    utilizing a diving suit. This cable connects from France to
    Singapore via 16 landing stations, which is capable of carrying 2.3
    Tbit data per second. [@bump_2013_three] 

    ![Physical path of
    Seamewe4[@telegeography_2022_submarine]](Img/literature_img_seamewe4.png){#fig:literature_img_seamewe4
    width="5.7in"}

    Indeed, cutting STC in the high sea is a low-risk, low-investment
    with enormous achievement for economic sabotage or geopolitical
    purposes, which drew the Russian attention to the cables in the
    transatlantic ocean, especially in North Atlantic.
    [@hicks_2016_undersea] As one of the world's most cable crowded
    water, the STC in the north Atlantic is responsible for more than
    90% of internet bandwidth between Europe and North America.
    [@inc_2020_submarine] Recent evidence shows an increasing Russian
    naval activity was even greater than the Cold War level.
    [@bbc_2022_russian; @shalal_2017_russian] Kremlin has two main
    weapons threats to the STCs: submarines and surface spy vessels that
    can deploy remotely operated vehicles or crewed submersibles.
    [@sutton_2021_5] For example, Losharik is a specialized nuclear
    submarine that can be carried by a larger 'mother' submarine over a
    long distance. Before its fire accident in 2019, the Losharik could
    perform topographical research and threaten STC within 1000m below
    the sea. [@roth_2019_fire] As for the surface vessel, Yantar is the
    most famous one, a 'special purpose intelligence collection'
    employed by the Russian Navy, this title is also seen as a euphemism
    for a spy ship. Considering, Yantar's deployment and field surveying
    often near the STCs and occasionally turned off the AIS noted off
    the attention from NATO countries. [@sutton_2021_russian]

-   Landing station: In contrast with the invisibility of the STC under
    the water, the on-shore cable landing station is a more obvious
    target. As the terminal of the STCs and the switching site between
    TTC and STC, CLS are often located in a town away from major cities.
    [@csric_2016_august] For budgetary reasons, many countries share one
    landing site for multiple cables, and the landing site is often less
    benefited by military forces. For example, the CLS in Bude (a town
    in England) connects eight STC, but the closest tourist trail is
    only 200m away from the main office. [@googlemap_2022_s] This
    clustering could lead to a greater risk to national security when
    facing unlawful violence(e.g. terrorists). [@sechrist_2012_new]

-   Espionage: Instead of breaking down the network, extracting the data
    without being notified is more in the interest of the attacker.
    Espionage can be accomplished in three ways: inserting a backdoor
    into the cables or other hardware components, targeting the CLS, and
    intercepting the cables at sea. [@morcos_2021_invisible] Each one is
    easier than the one before it, and the last one is believed to be
    the most challenging in engineering. [@chirgwin_2014_spies] Suggests
    that placing secret devices by removing protected armour without
    damaging the high sensitive optic fibre from the high water pressure
    shock is less likely to happen under the current technology. On the
    one hand, if the target cable is located m below sea level, the
    diver will be unable to withstand the water pressure, and the
    manipulator arms on the submersibles will be unable to polish and
    splice the fiber in a dust-free environment. Practically, it is much
    easier(and legally) to tap the data on the landing stations. A
    document released by the Washington Post revealed a secret system
    called \"Upstream\" from NSA was designed to access communication on
    fibre cables without damaging the existing connection.
    [@timberg_2013_nsa] As a result, because the UK is the entry point
    from the Atlantic and 80% of fiber data flows through the US, the
    CLS in Britain is the ideal location to deploy such a system.
    [@khazan_2013_none]

[@suganami_2017_the] Illustrates a concept of viewing data as critical
infrastructure in part of the complex global internet supply chain, in
the way that identifying the STC in the IoT environment rather than the
cable itself. Hackers may remotely control the STC network management
system to gain administrative rights. From that point, they could
identify physical or software vulnerabilities, disrupt the data traffic
or create backdoors for further usage. [@morcos_2021_invisible] It is
really likely to occur according to [@sechrist_2012_new], most of the
firewalls and the secure protection software in most network management
systems are not up to date.

At the point of writing, there has been no significant global internet
failure directly or indirectly caused by STC in the past decades. Even
if we ignore the fact that the cable failure was caused by natural
disasters, global STC connectivity remains fragile from a legal or
military standpoint, and even terrorist organizations from the
standpoint of ransoming for EU-US financial market stability.
[@clark_2016_undersea]

## Regulations and international law applied to STC

Ban Ki-moon, the former Secretary-General of the United Nations sums up
the wisdom in the Oceans and Law of the Sea Report [@un_2016_submarine]
*\"Submarine cables are a fundamental component of the critical global
infrastructure and play a direct role in sustainable industrialization;
indirectly they contribute to all other areas recognized as important
for sustainable development.\"* Just like any diplomatic business, as a
transnational communication system, STC connects multiple countries,
even different continents, this dramatically complicates the
jurisdiction. The attention of international law protection has been
extended to the STC, Tallinn Manual - an academic, non-binding study on
cyber law written by a group of NATO experts state that *\"(STC)
generally are treated in the same fashion as cyber infrastructure
located on the land territory\"* [@schmitt_2017_tallinn]. The proper
legal position of STC, however, is based solely on two international
agreements: the 1884 Convention for the Protection of Submarine
Telegraph Cables (Cable Convention) [@cableconvention_1884_1884] and the
1982 United Nations Convention on the Law of the Sea (UNCLOS)
[@un_1982_united]. Cable Convention was the result of 20 years of
industrial experience of the submarine telegraph cables at that time,
which was not the only product of diplomacy but also combined the
reflections of the fishery, ocean transportation industry, navy and
electrical engineers from 27 countries. The author summarized some key
articles from the Cable Convention as they are still the foundations of
the STC regulations.

i)  The convention applies to the cable even it is outside of
    territorial water.

ii) Any intention or culpable negligence break or injury on an STC will
    be subject to criminal penalties. But it is not applying to the case
    where captain damaged the cable to save the ship or his passengers.

iii) If a cable was broken or injured during the laying or repairing of
     another cable, the owner of the laying cable shall bear the cost of
     repairing.

iv) The vessel working on the laying or repairing submarine cable shall
    confirm the signal with the few preventing collisions at sea. Other
    vessels shall withdraw and keep the distance of one nautical mile,
    so not to interfere with cable laying or repairing operation.

v)  If a vessel can prove they have sacrificed an anchor, a net, or
    other fishing gear in order to avoid injury of a submarine cable.
    The owner of that submarine cable shall pay over these losses.

vi) This convention does not apply when a country is in a war.

If Cable Convention only gives some basic guidelines for vessel
operation and STC damage compensation, the more recent UNCLOS provides a
standard framework of responsibilities, supervision and regulations
across the nations. [@carter_2010_submarine] The UNCLOS divides the
marine area into five zones. [@noaa_2015_noaa] Four primary zones can be
identified in terms of STC jurisdiction. [@davenport_2012_submarine]

i)  First zone includes internal water and territorial waters, which
    marks any water inside of \"baseline\" [@westington_2002_us] or the
    sea within 12 nautical miles from the baseline. In this zone, the
    country has full sovereignty of the STC, laying or repairing cable
    needs to be applied via diplomatic communication channels
    beforehand. In many countries, the criminalization of espionage in
    this area is also written in the local law. [@kraska_2015_putting]

ii) Next is Contiguous zone, a buffer band within 12-24 nautical miles
    from the baseline, which aims to prevent the legal issues regarding
    *\"customs, fiscal, immigration or sanitary laws and regulations\"*
    [@pyc_2017_the]. However, its functionality is done by the server
    site where the STC lands or the government cyber security
    intelligence agency.

iii) Following that is the Exclusive Economic Zone(EEZ), which extends
     up to 200 nautical miles from its baseline. The nation is entitled
     to develop or harvest any natural resources and establish
     artificial islands here. [@louisiana_2005_demystifying] However, in
     article 79, UNCLOS recognizes the right of everyone to laying
     cables within the EEZ zone [@un_1982_united]. Therefore, the
     ownership and the cable destruction responsibility are still quite
     vague at this stage.

iv) Lastly, any water beyond the EEZ and continental shelf is the High
    Seas, where domestic law no longer applies. Anyone may lay or repair
    STC in the high sea, but the damage or injury to other STC still
    needs to face judgement from the international court of justice.
    [@davenport_2012_submarine]

To improve the existing legal status of STC, [@rishi_2017_undersea]
proposed an assumption by assigning a lead agency to create protection
zones in the shallow water where activities are likely to damage the STC
should be strictly prohibited there. Under such a framework, broader
maritime planning and better spatial management need to be considered,
with the circumstances of an increasing gap between the importance of
the STC and the amount of legal protection it receives. 

## Barriers to connectivity

Even though STC is a world spread infrastructure, there are still 2.9
billion people who do not have access to the internet, especially in
developing countries where the people are not covered by 2G or 3G
signals. [@itu_2021_29] 

The barriers to effective use of internet data also apply to the ability
to digitally connection rather than the physical/software failures in
the STC system. The challenges facing global broadband connectivity are
discussed in more detail below.

### Lack of infrastructure

Accessibility to the internet has closed roll-out with infrastructure,
Most ISPs do not deploy infrastructures in areas with less commercial
prosperity. Although constructing new infrastructure is usually
associated with coverage, barriers such as the lack of electricity, lack
of road(harbour) access, and underdevelopment of domestic backbone
networks. These observations are particularly prevalent in the rural
areas and low-income regions, the challenge in terrain; higher
deployment costs and government corruption give a longer cost recovery
period. [@chen2004global]

The stable supply of electricity is the essential prerequisite for any
internet connectivity, to sustain the functional working of both landing
stations and sub-base stations. Fig
[2.3](#fig:literature_img_electricity){reference-type="ref"
reference="fig:literature_img_electricity"} shows a map indicating the
lack of electrical infrastructure around the world. The lack of
electricity is particularly serious is Africa. The region is also known
for its poverty [@worldbank_2011_poverty] and more than half of the
population does not have access to electricity. [@worldbank_2018_access]

![Electricity infrastructure
distribution[@DELPORTILLO2021102092]](Img/literature_img_electricity.png){#fig:literature_img_electricity
width="5.7in"}

### Affordability

Internet affordability can still be a barrier even if the electricity
infrastructure is in place. By estimate, there are still around 10% of
individuals who do not have access to the internet globally.
[@johnson_2022_internet] At the regional level, users in Africa are
paying 3 times the global median price for the broadband service fee for
a similar level of service. [@itu_2022_global]

People's disposable income and internet data package subscription fees
are the two major barriers to utilising broadband services. Broadly
speaking, the device cost has always been the most significant issue for
low-income groups, but recently intense price competition amount
terminal device brands and a well-established hardware reuse chain has
dramatically reduced the price barrier. The monthly data package
services have become a luxury, especially in the COVID-19 era, the fixed
broadband services play a bigger segment in people's gross national
income(GNI) which climbed from 2.9% in 2020 to 3.5% in 2021.
[@itu_2022_global] The ITU is aiming for more affordable broadband
services to everyone with less than 2% of GNI by 2025.
[@itu_2021_affordability]

### Extend connectivity

However, as an alternative technology to replace STC, the application of
satellite internet has re-gained popularity recently. [@ashford2004non]
Despite the limited market share that satellites internet holds in the
global telecommunication market, the quality of the services is
sufficient for its users, [@DELPORTILLO2019123] statistical estimates of
the total system throughput for different technologies.

Utilizing non-synchronous orbit satellites rotate around the earth's
orbit, providing wireless internet connection to the customer near the
earth's surface. If the satellite is located in geostationary earth
orbit, the user will suffer from higher latency and more limited
bandwidth than STC. Low Earth orbit (LEO) satellites can significantly
mitigate these issues. Still, LEO acquires hundreds of thousands of
satellites to provide worldwide coverage, which gives higher standards
to the internet service provider(ISP). [@deutschmann_2021_broadband]
Regardless, LEO has always been the most commercially successful
satellite internet service and also gains extra technical standpoint
during the manufacturing processes, which resulting a higher standard on
user budget than STC, as more professional technical devices and
expensive data packages need to be pre-purchased before usage.
[@gsma2016digital] On the other hand, if the service area is retained in
-$km^2$ on a small number of base stations is required to achieve
suboptimal working conditions with minimal maintenance.
[@djuknic1997establishing] This makes the LEOs particularly useful for
facilitating the telecommunication infrastructure damage recovery
[@alnajjar2014low] to permanent communication infrastructure in rural
areas. [@bleicher20185g]

# Data {#sec:Data}

This section demonstrates and discusses the data was identified to
characterize the essential requirements and to estimate the STC network
system performance, before the highlighting any analysis. The STC data
process can be categorized into 4 sections: dataset gathering, dataset
pre-process, data storage, data category classification.

## Dataset gathering

There are three comprehensive open datasets of the global STC were
utilized in this research. All three datasets provide some information
on cable name, cable length, ready to service date and cable owner. They
differ in extra information(eg number of fiber pairs) and number of
cables documented

-   Submarine cable dataset [DS1](www.submarinecablemap.com/api/v3): The
    *Submarine Cable Map(SCM)* is an online web map service powered by
    TeleGeography, which gives the world STC GPS location and its
    landing points. TeleGeography has 15 years of experience in
    telecommunications market research and consulting. Its research
    results sponse to companies such as Amazon AWS, Cisco, and Google
    cloud. 

    [DS2](https://subtelforum.com): For detailed STC properties, the
    *Submarine Cable Almanac(SCA)* offers information including planned
    budget cost, number of fiber twisted pairs. This report updates
    quarterly with the most recent data and technical breakthroughs in
    the submarine telecommunication industry. 

    [DS3](https://www.infrapedia.com/app/subsea-cable): The
    *Infrastructure Map* provides detailed STC designed capacity and
    annual lit capacity of the global STC network. The data in
    Infrastructure Map is directly collected from the official website
    for each STC and peer reviewed by a group of experts from
    TeleGeography and the community. 

-   Global bandwidth throughput dataset
    [DS4](https://www.itu.int/en/ITU-D/Statistics/Pages/about.aspx):
    Recall that more than 98% of global internet transmission is handled
    by the STCs[@winseck_2017_the], the annual survey from ITU documents
    the \"total international bandwidth usage per second\" and
    \"individual bandwidth usage for each internet user per second\"
    across 237 countries from 2007 to 2020. ITU collected and harmonized
    the information from the state telecommunication/ICT ministries or
    national statistical offices.

## Data pre-processing

For various reasons, the cable property data on few cables are not
publicly released. In very rare cases, the property data on an STC shows
a conflict of information between datasets or significantly outlies the
rest of the values under that data property. To overcome this, the
author uses Interactive Transmission Network Maps
[@bdt_2022_infrastructure] as the additional validation dataset and
adopting the majority rule strategy from the voting system
[@kuncheva_2003_limits] to decide the most reliable information within.
It is worth mentioning that the data from SCA holds two votes as the
data properties are reviewed more frequently(4 times every year) than
other datasets. All the datasets mentioned above remain in the public
domain for any non-commercial usage.

## Dataset Storage

All the raw data and processed clean data are stored in an SQLite
database which is kept in secure cloud storage to ensure the data
confidentiality, availability and durability.

## Data category classification

Since the research scope focuses on submarine telecommunication cables,
the following types of fibre optic cables are not included in this
research. Firstly, the fibre cables lay after the STC landing point
which is also known as the terrestrial telecommunication cable(TTC),
these cables play as the highway to provide the domestic internet
connection or speed up the data traffic between STC landing stations
from one country to another. TTCs are usually constructed and controlled
by the local ISPs, they are much longer and harder to trace the
locations. For example, the Zayo group built at least 170222km of TTC in
the contiguous US where most of the connections between the east coast
and west coast are relayed on this. [@infrapedia_2022_zayo] Secondly,
the cables used for military or national security purposes are excluded
because their existence is extremely confidential and they are using
private networking, which is not open to civilian broadband.
[@ruffin_2000_a] The third exclusion consists of private cables and dark
fibres, these cables are either used to transmit private information
between servers with high standards on performance and security or the
constructed cable but currently not on services. Because of their
special usage, the network topologies are usually point-to-point, star
or ring which do not contribute to the majority of the people.
[@sima_2007_deliverable] Lastly, the STCs which are only designed to
serve particular sea operation stations are also excluded. A typical
example is oil drilling platforms where the single channel communication
is directly connected to the TTC and transmission is used purely for
commercial reasons. For example, *Abu Dhabi* is the cable with a length
of 420km which connects the UAE and Abu Dhabi National Oil Company's
offshore production facilities.
[@nielsen_2017_submarine; @jandenul_2021_jan]

-   High level data description The High level data description
    aggregates the data based on the countries' belonging which gives an
    abstract view of the STC connection.

-   Low level data description Low level data helps to explain the STC
    connection in more concrete terms, such as STC landing cities and
    service status. A coastal country may consist of one or many landing
    cities, this will dramatically increase the number of nodes and
    edges to be considered. This level also gives the most detailed
    entries of their construction in the network of connections, as each
    edge is labeled with a unique color to identify their route path
    under the sea.

# Methods {#sec:Methods}

To approach the goal of identifying the vulnerability in the STC
network, the author first introduces the key concepts and terminologies
in this study. Secondly, we assess the future risk of bandwidth
shortages due to the increasing demand for internet throughput.
Subsequently, a framework of STC data flow and various centrality
analysis were proposed to identify the potential influential
path/landing station. Finally, an STC improvement scenario in the
southern Pacific Ocean is described.

## Graph theory and Network science

Network science and graph theory are two highly overlapped fields to
model and mathematically describe the relational connection between
multiple objects, even though the two research fields can be used
interchangeably to illustrate a similar idea: the objects (nodes,
vertices) are associated by a logical connection (links, edges).
[@albertlaszlabarabasi_2016_network] But the nuanced differences between
the two statements still exist, which means they can not be interpreted
with one.

-   Graph theory is a branch of discrete mathematics that provides the
    fundamental theorem and essential algorithms for the given graph.
    [@neo4j_2022_graph] The entity of node and edge object could be seen
    as a set of objects with different types of items.

-   In contrast, network science focuses on the observation of
    real-world representations of the connection to understand the
    structure and quantify the dynamics of the complex system between
    the objects. [@friedrich_2019_from] For example, society is the
    linkage between individuals under the association of families,
    friendships, classmates and coworkers etc.

#### Internet routing in graph theory

![Computer routing in graph theory
[@albertlaszlabarabasi_2016_network]](Img/grouph_img_computerRouting.png){#fig:Computer_routing
width="5.7in"}

The construction of the internet routing network system is valid for an
undirected graph as the internet cables provide synchronous
communication, allowing data upload/download to happen simultaneously
from both ends. [@gkantsidis_2003_spectral] The system components in
such a graph are often called nodes and each direct interaction between
two nodes is also known as edge.

In a network system, we label a node with $V_i$, where $i$ is the index
of the components in such network system, which is labeled as
$i = 1,2,3...n$.

$E$ is a set of edges between the nodes where each edge association is
denoted as $E_{xy}\rightarrow{((x,y\subseteq V_i) \cap (x\neq y))}$

We denote $K_i$ as the number of edges directly connected to the node
$V_i$ in the network. This number is also known as the degree. In an
undirected network system, the total number of edge $L$ can be
calculated by the following equation. $L=\frac{1}{2}\sum_{i = 1}^N K_i$

#### Attributes in the STC graph

To review the global STCs from multiple aspects of dynamic correlations
and bring quantitative constructions needed for the analysis. The
network science and graph theory provide methods to take into
consideration of the quantitative relationship by inserting the
numerical values into the nodes and edges within the STC network. The
network's nodes and edges attribute definition is presented in Table
[\[table:Network_attribute\]](#table:Network_attribute){reference-type="ref"
reference="table:Network_attribute"}

::: tabu
to 1 **Category** & **Attributes** & **Relevance**\
Node & Label & The name of landing city and country\
Node & Position & Lon/Lat of of the given node\
Node & Adjacent & A list of nodes that directly connect by an edge\
Edge & Label & The name of cable\
Edge & Connection & Two nodes that construct this relationship\
Edge & Capacity & The designed maximum data transmission can be carried
of the STC per second\
Edge & Length & The length of the STC between two landing points\
Edge & Cost & The budget cost when the cable was designed\
Other & Other & Undirected graph, each node has the infinite capacity to
route data between two cables
:::

#### Keywords/philosophy in the network science

A variety of network analytical toolboxes are available under such a
quantitative network, enabling the analysis approach to measure the
topology and attributes of the network from a collection of
multi-dimensional information in Table
[\[table:Network_philosophy\]](#table:Network_philosophy){reference-type="ref"
reference="table:Network_philosophy"}

[@albertlaszlabarabasi_2016_network][@diestel_2017_graph][@hoffman_2021_methods][@muscoloni_2016_richclubness][@najera_2021_measuring][@newman_2017_networks][@saqr_2020_robustness][@xavier_1998_introduction]

::: tabu
to 1 **Concept** & **Explanation** & **Application**\
Degree & Number of edges connecting to a node & To gain observation of
the distribution of connection in a network\
Path & A set of edges that connects from $V_i$ to $V_j$ & A allocate the
spatial movement from the origin to destination for a given condition\
Neighbors & The node($V_i$) is neighbor to a node($V_j$) such that the
edge $E_{V_i,V_j}$ exists. & The diversity of the choice when routing
from one node to another\
Connectivity & The measure of the connection between the nodes, there
are two or more isolated sub-graphs if no path exists between any given
two nodes & If the global internet can be accessed between two
countries, either they are connected by STC or the combination of STCs
and TTCs\
Flow & The non-negative capacity associated with each edge & The
capability of the data movement that no edge can exceed this limitation\
Centrality & A measure to the importance of the node in a network & To
classify the STC landing points based on their cohesiveness. This allows
centrality to be considered as a coefficient to describe node
importance\
Betweenness & Betweenness centrality measures the number of times a node
lies on the shortest path between other nodes. & Provides another view
of network elasticity by considering the most influential routing nodes
in a network. For example, the transit stop in a connecting flight has
higher betweenness in the flight network\
Rich club coefficient & A measure to identify the presence of the
connection between well-connected(a large number of degree) nodes & The
rich club coefficient assesses the group robustness and the ability to
remain functional when the key group member quit from the collaboration
:::

## Bandwidth shortage

Prior to performing any suitable analysis, there is a problem that needs
to be resolved. The raw dataset contains certain bandwidth data that is
not accessible to the general public. To overcome the problem of missing
data on bandwidth, the author decided to employ Butter's law of
bandwidth to estimate the potential bandwidth capacity that can be
carried by STC. In the context of STC, optical fiber is the most
fundamental and essential material in photonic data communication.
Similar to Moore's law, Butter's law is based on the historical
observation that the amount of information that can be transmitted
through the optical fiber has been doubling every 9 months thanks to the
development of new technologies such as wavelength-division
multiplexing.[@hadaway_2016_16][@buttle_2014_internet]

$$n_i = n_0\times2^{(y_i-y_0)/T}
\label{Butter's Law of bandwidth}$$

Where $n_0$ is the initial bandwidth throughput in the year $y_0$, $T$
is a constant reference to the number of years required to double the
bandwidth throughput. The value of $n_i$ is the resultant bandwidth in
the year $y_i$, thus its logarithmic value shows a linear dependency on
$n_0$.

## Policy-Based Routing

The path between the origin and destination in a network could either be
statically predefined or adaptively changed based on the algorithm. In
many real world router setups, the routing decision changes dynamically
based on the instantaneous status within the network, the factors
leading to the new route could be: current network topology, traffic
load and latency. [@medhi_2017_network] The first priority for all the
routing algorithms is to prevent deadlock with the secondary objective
of achieving maximum efficiency by minimizing the routing cost.
[@duato_2003_chapter] Considering an undirected graph(G) with N nodes
and M edges, where each edge is assigned a weight to represent a
physical property of 'distance'. The target is to find a route between
two nodes along a set of edges. Therefore, the theoretical minimum
routing cost is the sum of weights under all the edge choices. The
routing algorithm that mathematically discovers the best route is called
the shortest-path algorithm. There are four types of weight properties
applied to the edges in their investigations, they are Simple, Spatial
length, Budget cost, Bandwidth capacity. The detailed summary
description can be found in Table
[\[table:Edge_properties\]](#table:Edge_properties){reference-type="ref"
reference="table:Edge_properties"}

::: tabu
to 1 **Property** & **Symbol** & **Explain**& **Application**\
Simple & $C^S$ & Each edge weight is assigned to value of 1 & The path
where data flows through with the minimum number of edges along the
way.\
Spatial length & $C^L$ & The edge weight is the actual length of STC
between the landing stations & When the data transmission speed is
constant, time is directly proportional to distance. The route with the
shortest length in STC gives the minimum time taken for data to travel
between landing stations.\
Budget cost & $C^C$ & The edge weight is the average cost of deployment
based on the length & STC owner recovers the cost of deployment by
charging the money from the local ISP. An STC may be preferred by ISPs
due to its low charging price.\
Bandwidth capacity & $C^B$ & The edge weight is the maximum data
throughput capacity that can be carried in that cable & Each STC is
labeled to a design bandwidth capacity, it is the theoretical limit of
data carriage ability. It is useful when users are sending large size
files via STC.
:::

### Network Analysis

To analyze such complex network with a large number of nodes and edges,
the research boundary is not only the physical connection of STC but
also an abstract quantitative network to deal with the communication
between the nodes and edges.

As the weakness may either occur on the underwater STC or the cable
landing stations, the locations in the global STC network with the high
value of centrality gain more interest than others. The node with high
centrality referred to the importance of an actor in a topological
network structure. [@hoffman_2021_methods] There are two centrality
measurements employed in this investigation: degree centrality,
betweenness centrality - The detailed strength and weaknesses can be
found in Table
[\[table:Network_analysis_compare\]](#table:Network_analysis_compare){reference-type="ref"
reference="table:Network_analysis_compare"}

::: tabu
to 1 **Concept** & **Definition** & **Explain**& **Application**\
Degree centrality & The count number for edge directly connect to the
node [@sharma_2013_degree] & A node with a higher degree of edge acts
the more central role of a network & Degree centrality shows how many
nodes can be directly reached by such node, even though this node might
be far off on the boundary of this network\
Betweenness centrality & $s(E)={E(x,y)}$ [@hansen_2019_analyzing] & The
node plays a hot spot role in many shortest paths & If all the
information must pass through a node before reaching the destination,
this node is the most important as the efficiency of the communication
is dependent on it. But betweenness centrality compute intensive in
large scale network
:::

### Network optimization

To overcome the problem of STC incidents, rerouting the data flow to an
alternative or secondary infrastructure would in worst performance but
functional internet services. If the country/region only consists one
STC connection, it is considered a high-risk country for STC failure due
to its low redundancy. South Pacific Ocean has been known for its
isolation from the majority of the world, and the deployment of STC is
not as well-developed as the rest of the world. This makes the
country(such as Tonga) extremely vulnerable and dependent on its only
STC to communicate with the rest of the world, but this risk could be
mitigated by laying additional STC cables to increase its network
redundancy. [@laporte_2015_chapter] Inspect a similar issue from Chinese
postman problem(CPP) and provides an idea from another perspective.

::: algorithm
input: Grouph $G_{i}$ output: Grouph $G_{o}$ Begin odd_list = \[\] if G
== EulerianCircuit return G while x in G.node if x.degree % 2 == 1
odd_list.add(x) while odd_list != empty distance = MAX node = i, j for x
in odd_list for y in odd_list if 0 \< path(x,y) \< distance i = x j = y
connect_nodes(G, i, j) remove_node(odd_list, i, j) if G !=
EulerianCircuit start again else return G End
:::

CPP indicates additional edge(s) needed to form an Euler circuit graph,
a walk can visit every edge exactly once by starting from any given
node. [@tan_2005_chinese] Thus, each node will have a positive number of
pairs of edges to provide the route for the incoming and outgoing paths.
This provides a baseline of one redundant STC for each landing station.

Over-redundancy, on the other hand, is a by-product of the CPP, which
creates extra edges in order to satisfy the CPP algorithm. Although
redundant edges result in a more reliable network design, they also come
with higher building costs. Here, the author introduces the rich-club
coefficient which describes the connectivity between nodes with a high
degree centrality, under the presumption that nodes with higher degrees
centrality are obtaining more geographic advantages in the network.
[@ma_2015_richcores] $$\phi(k) = \frac{2 E_k}{N_k (N_k - 1)}$$

# Results {#sec:Results}

In this section, author presents the results of the STC network
vulnerability analysis at two levels where their topologies are not
pre-specified.

The analysis starts off with a generalized country level STC network
connection, focusing on the shortage of the STC due to the natural
growth in the international internet bandwidth and the country's
internet robustness when multiple STC failure happens simultaneously. To
better understand internet accessibility, the author acquires a
comprehensive route level network for the STC paths. The analysis is
based on 4 edge property measurements with 3 assessment approaches.

## Study scope

As a marine based infrastructure, STC is not suitable and applicable to
be deployed in all countries. Since the first STC was laid in 1989, the
global broadband network interconnects almost all the countries in the
world with 183 countries owning at least one STC cable. Countries left
out were either territorially landlocked(eg. Mongolia and Ethiopia) or
geopolitically less interested into it(eg. North Korea).

![Map of first STC cable laying
year](Img/result_map_STCYear.png){#fig:First_STC width="5.7in"}

## High(country) level STC

### Distribution of STC between countries

The high level data aggregates the territorial information at the
country level, which includes the mainland, dependent areas and overseas
territories. [@nationsonline_2022_countries] This makes some small
overseas islands part of its administrative territories. For instance,
Guam is an unincorporated territory of the US in the western pacific
Ocean [@usdoi_2016_definitions] which is responsible for 7 out of 20
STCs connections between East Asia and West America.
[@telegeography_2022_submarine] This leaves 396 edge connections spread
over 183 countries.

![Country level
connection](Img/result_map_countryFirstCable.png){#fig:Country_Connection
width="5.7in"}

Figure [5.2](#fig:Country_Connection){reference-type="ref"
reference="fig:Country_Connection"} presents the visualization of the
country level STC connection, where each node is the representation of
one country and at least one edge is directly connected to it. The edge
width is proportional to the count of STCs in charge of the end-to-end
connection between two nodes.

![Country degree in
histogram](Img/result_his_countryDegreeCount.png){#fig:Country_Degree
width="5.7in"}

Combined with Figure [5.3](#fig:Country_Degree){reference-type="ref"
reference="fig:Country_Degree"}, a high clustering of the domestic
connections in Southeast Asia and Europe can be expected. As the
majority of countries have fewer than 25 direct STC connections to other
states, in this case the design of STC tends to build a loosen and
distributed network in a small area. Countries such as
$K_{Indonesia}=224$, $K_{United States}=216$, $K_{United Kingdom}=118$
are way outnumbered by the rest of 180 countries, accounting for 26% of
global landing station count. These nations typically have far more
redundant cables than the rest of the world as a result. With an density
of $\frac{1}{17}$, this network has a nonnegligible gap between its
actual edges and its maximum number of edges.

### Bandwidth shortage due to the nature growth

Despite the development of the local caching services(eg. CDN) over the
last two decades, increased investments in STC by the tech giants and
continued construction of data centers around the globe, the demand for
international bandwidth usage seems to increase in the next few years
according to the estimation and statistics from ITU. [@itu_2022_country]

![Country most vulnerable to international bandwidth
shortage](Img/result_hbar_capacityGap.png){#fig:Capacity_Gap
width="5.7in"}

Figure [5.4](#fig:Capacity_Gap){reference-type="ref"
reference="fig:Capacity_Gap"} shows the top 10 countries that have the
risk to overcome the gap between international bandwidth served by the
STC and increasing internet services demand from its people. Even though
Poland, Romania, and Croatia are the countries most at risk from this
scenario, as members of the Europe Union, the actual deficit is less
than the paper result since the bandwidth shortage can be made up by TTC
from adjacent countries. In contrast, countries with less political
stability(eg. Syria) and those that are geographically located in an
island(eg. Vanuatu) will suffer be more affected by this, especially
during the internet rush hours.

### STC redundancy analysis

With over 100 yearly accidents from human unintentional incidents (eg.
fishing dredge and anchoring) to natural hazards as well as the
potential hostile attack for military purposes. [@mauldin_2017_cable] It
is not hard to imagine the scenario where a country's internet services
is disrupted by multiple cable losses at the same time. The strength of
the internet is evaluated by determining the residual bandwidth after
removing the cables with the highest bandwidth in order to simulate the
effects of such a disruption in the worst case scenario.

![STC country bandwidth robustness
compare](Img/result_waffle_countryCompare.png){#fig:Bandwidth_Compare
width="5.7in"}

First, nations with less than three redundant cables are regarded as
being more susceptible to internet connection problems. Since
simultaneous STC failure on three cables has historically been extremely
unlikely, it would also be advantageous if the nation could continue to
maintain essential communications with the outside world. Figure
[5.5](#fig:Bandwidth_Compare){reference-type="ref"
reference="fig:Bandwidth_Compare"} lists the share of countries falling
under this use case. The STC vulnerable countries($K_{i}<4$) can not
obtain the STC connectivity, which could be crucial for some island
countries or territories since the absence of the TTC means a potential
loss of 100% of the international bandwidth. STC robust
countries($K_{i}>=4$) are less likely to suffer from this however.

![Spatial distribution of STC vulnerable
countries](Img/result_ring_countryVulnerable.png){#fig:Vulnerable_Countries
width="5.3in"}

To further investigate the STC robustness, Figure
[5.6](#fig:Vulnerable_Countries){reference-type="ref"
reference="fig:Vulnerable_Countries"} shows the spatial distribution of
the STC vulnerable countries. The inner ring provides the chunk for each
county while the outer ring represents the overall bandwidth from each
continent. Asia \> Africa \> North America \> Oceania \> South America
\> Europe are the continents with the highest percentage. According to
the data, Asia is the region that is most at risk because it contributes
the biggest number, yet the segment is made up of a handful of countries
with high bandwidth. In contrast North America and Africa, a smaller
sector from each country with a high number country count. As a case
concerns South America, which only consists of 3 vulnerable countries:
French Guiana, Guyana and Suriname with an evenly distributed bandwidth
allocation. The countries only deliver a summed capacity and cable count
of 209.65Tb/s and 2.67cables/country.

![Scenarios of STC failures with most robust
countries](Img/result_hbar_bandwidthRobust_country.png){#fig:BandwidthRobust_Country
width="5.7in"}

![Scenarios of STC failures with lest robust
countries](Img/result_hbar_bandwidthRisk_country.png){#fig:BandwidthRisk_Country
width="5.7in"}

There are 94 countries assigned to the STC robust group, as each of
which is capable of withstanding three or more STC losses. The nation
might experience a decrease in its capacity for international bandwidth
as a result of a cable breakdown. However, losing one or two cables is
more likely to occur in the real world. Figure
[5.7](#fig:BandwidthRobust_Country){reference-type="ref"
reference="fig:BandwidthRobust_Country"} and
[5.8](#fig:BandwidthRisk_Country){reference-type="ref"
reference="fig:BandwidthRisk_Country"} shows the resultant remaining
bandwidth in percentage to retain internet connectivity if the top three
widest cables fail.

Due to its great loosen cable distribution and accessibility of
redundant cables, the USA is the top player in terms of bandwidth that
is still available despite multiple cable failures, with cable edge
$K_{usa}=29$ and estimated potential bandwidth of 1479.76Tb/s. The
overall US bandwidth can be predicted to decrease by 250Tb/s (16.89%) as
a result of the connection loss of its widest cable *Dunant*. Even in
the worst case scenario in this study where top3 cables are failing at
the same time, USA would still obtain the remaining international
bandwidth capacity of 642.43Tb/s which outnumbered the actual
demand(41.16Tb/s in 2022). [@itu_2022_country] Besides that, the
continental USA is geographically adjacent to Canada and Mexico which
may provide additional TTC bandwidth capacity if needed.

With an estimated 98.66% bandwidth loss due to disconnect in its biggest
cable, Havhingsten/Celtix Connect-2, and the remaining 1.42Tb/s capacity
from the other three cables, the Isle of Man is a poor example of the
cable distribution design.

## Low(landing station) level STC

To better understand how STC is distributed across the world, the author
also concerns a detailed low-level route for the STC paths. Figure
[5.9](#fig:LandingStation_network){reference-type="ref"
reference="fig:LandingStation_network"} below outlines the landing
stations and the geographical path of the global STC connections.

![STC network in landing station
level](Img/result_map_landingDistribution.png){#fig:LandingStation_network
width="5.3in"}

From Table
[\[table:LowLevel_Summary\]](#table:LowLevel_Summary){reference-type="ref"
reference="table:LowLevel_Summary"} we can also observe a highly skewed
STC cable data distribution as the mean values are closed to 75% with a
rapid increase in cable capacity, cable length, cable cost after that.

::: tabu
to 1 & **Country** &**Landing station** & **Cable capacity(Tb/s)** &
**Cable length(KM)** & **Cable cost(million USD)**\
count & 183.00 & 1335.00 & 501.00 & 501.00 & 501.00\
mean & & & 50.42 & 3406.04 & 119.61\
std & & & 231.24 & 5986.72 & 182.44\
min & & & 0.00 & 5.00 & 0.25\
25% & & & 0.25 & 225.00 & 15.00\
50% & & & 5.91 & 775.00 & 40.10\
75% & & & 44.38 & 3472.00 & 122.00\
max & & & 4000.00 & 45000.00 & 1007.78
:::

### Policy-Based Routing

Considering the nature of routing in a complex network, the path between
source and destination node can be selected from vast options. Figure
[5.10](#fig:Path_YemenIndia){reference-type="ref"
reference="fig:Path_YemenIndia"} shows a case of data communication
between Yemen-India via STC. There are numerous alternate paths that can
be found, many of which cover greater distances or evade more landing
sites, even though there are only six routes shown on the map.

![STC route options from
Yemen-India](Img/result_map_path_YemenIndia.png){#fig:Path_YemenIndia
width="5.7in"}

A variety of information must also be taken into account while
approaching network routing and choosing the best path.
[@baumann_2007_a] In this case, the author compare the routes from
Bude(UK) to Shanghai(China) to identify the optimal path under different
use case for data transmission.

![Low-level shortest-path route
($C^S$)](Img/result_map_shortestPath_node.png){#fig:Shortest_Node
width="5.7in"}

![Low-level shortest-path route
($C^L$)](Img/result_map_shortestPath_latency.png){#fig:Shortest_Latency
width="5.7in"}

![Low-level shortest-path route
($C^B$)](Img/result_map_shortestPath_capacity.png){#fig:Shortest_Capacity
width="5.7in"}

![Low-level shortest-path route
($C^C$)](Img/result_map_shortestPath_cost.png){#fig:Shortest_Cost
width="5.7in"}

As Figure [5.11](#fig:Shortest_Node){reference-type="ref"
reference="fig:Shortest_Node"} to
[5.14](#fig:Shortest_Cost){reference-type="ref"
reference="fig:Shortest_Cost"} shown, the paths are chosen by the data
packages based on their routing policies. In such an instance, $C^B$
chooses a geographically longer route in exchange for a wider bandwidth
capacity in comparison to other routes. Using Mumbai(India) as the
routing transit station is the common practice in this study case. The
importance of Mumbai in global STC connection will be presented in
Section [5.3.2](#Degree_centrality){reference-type="ref"
reference="Degree_centrality"}. It is also interesting to see a high
overlap between the STC routes and some of the most important shipping
trade routes, take $C^S$ as an example, the route passes through the
English Channel, Strait of Gibraltar, Suez Canal, Bab al-Mandab Strait,
Malacca Strait before reaching its destination. It is risky for the
cables from anchor damage, as a large number of ships are right above
the STC cables in the shipping route area. In addition to that, cable
density in these regions are usually higher than normal due to the
narrow width alone the bank(205m for Suez canal), damage from natural
hazard or explosions may cause failure on multiple STCs.

### Degree centrality {#Degree_centrality}

The degree centrality offers a quantifiable measure to categorize the
nodes based on their cohesiveness, allowing us to evaluate the
significance of each landing station individually. Accordingly, the
count of adjacent edges for each landing station will be assessed,
Figure [5.15](#fig:landingDegreeCentrality){reference-type="ref"
reference="fig:landingDegreeCentrality"} captures the results of the
degree centrality based on the landing stations. Mumbai(India) is the
headmost with $K_{Mumbai}=160$ and 0.43 degree centrality, followed by
Shima(Japan) and Jeddah(Saudi Arabia), their high values can be
explained by the geographic importance as the transit countries. Japan
is the gateway to connect Asia and Pacific ocean, similarly Saudi Arabia
is located near the Suez Canal the shortest sea connection between Asia
and Europe. Another side of the coin, the landing stations with the
lowest degree centrality can be found in the island countries or regions
with only one cable connect to it eg. Aeng Batu Batu(Indonesia), Balluta
Bay(Malta)

![Low-level degree centrality
map](Img/result_map_landingDegreeCentrality.png){#fig:landingDegreeCentrality
width="5.7in"}

The landing stations with a high degree centrality are playing a more
significant role in the STC network, arguably such design is not ideal
in terms of risk assessment. The high degree centrality nodes consist
the feature of intensive connection, the failure in the node itself
cause by unexpected accidents (eg. power blackout, riots, terrorist
attack) would consequently in more serious damage to the communication
globally as the data routing can not proceed to the succeeding landing
station. Besides the landing stations mentioned above, Singapore is also
extremely valuable to the STC network but can not directly be observed
from the map. Because Singapore is a small island, the two landing
stations(Changi North and Tuas) are only 35km apart, the accident in one
landing station is likely to implicate another.

### Betweenness centrality

To account for the topological cable breakage at the sea, one important
issue that needs to be considered is the geographical distribution of
the cable usage while transmitting the data package. The betweenness
centrality returns the ratio in which the node is sitting alone on the
shortest path between any two nodes, it can be seen as a comprehensive
measure of the routing path selection in terms of the possibilities.
With a different focus on the data routing policies, Figure
[5.16](#fig:Betweenness_Overview){reference-type="ref"
reference="fig:Betweenness_Overview"} visualize the distribution of the
betweenness centrality individually while Table
[\[table:Betweenness_summary\]](#table:Betweenness_summary){reference-type="ref"
reference="table:Betweenness_summary"} statistically summarizes the
value.

![Betweenness centrality
Overview](Img/reult_line_NodeBetweenness_Overview.png){#fig:Betweenness_Overview
width="5.7in"}

![Betweenness centrality
Zoomed](Img/reult_line_NodeBetweenness_Zoomed.png){#fig:Betweenness_Zoomed
width="5.7in"}

::: tabu
to 1 & **Latency** & **Cost** & **Capacity**\
count & 7229 & 7229 & 7229\
mean & 0.015085355 & 0.016789418 & 0.019458784\
std & 0.043984581 & 0.051353499 & 0.064554104\
min & 0 & 0 & 0\
25% & 0.000892193 & 0.000609267 & 0.000675097\
50% & 0.002603469 & 0.002106302 & 0.002119711\
75% & 0.008613072 & 0.009043768 & 0.007870817\
max & 0.371998844 & 0.48875602 & 0.517119399
:::

Figure [5.16](#fig:Betweenness_Overview){reference-type="ref"
reference="fig:Betweenness_Overview"} displays a power-law distribution
pattern based on the betweenness centrality for each routing policy, and
Table
[\[table:Betweenness_summary\]](#table:Betweenness_summary){reference-type="ref"
reference="table:Betweenness_summary"} presents the relevant summary
statistics. In network science, this is a poor design since the
performance of the route choice is mostly dependent on a small number of
nodes. If the failure happens on the high betweenness centrality node,
this design would result in a dramatically deteriorate of the efficiency
of the data flow when the network is switched to the sub-optimal
route(eg. takes more time to the destination, narrowed bandwidth, higher
usage cost).Figure [5.17](#fig:Betweenness_Zoomed){reference-type="ref"
reference="fig:Betweenness_Zoomed"} provides a zoomed view of the first
500 nodes from Figure
[5.16](#fig:Betweenness_Overview){reference-type="ref"
reference="fig:Betweenness_Overview"}, showing a more in-depth data
pattern across various routing strategies. It is evident that Bandwidth
\> Cost \> Latency in the first 300 nodes, which mostly explains why
there is such a large gap between the mean value with the contrast of
little variation in 75% values from Table
[\[table:Betweenness_summary\]](#table:Betweenness_summary){reference-type="ref"
reference="table:Betweenness_summary"}.

Therefore, if any highlighted node or cable in Figure \"Betweenness
Latency\" to Figure \"Betweenness Cost\" fails, a greater loss in global
STC bandwidth can be expected when compared with the latency.
Furthermore, compared to other routing strategies, the distribution of
latency betweenness shows a shallow curve with a lower standard
deviation, which suggests a looser network with higher resilience. In
other words, transmission delay would be less affected by the disconnect
on a key node than bandwidth capacity.

![Betweenness centrality
map($C^L$)](Img/result_map_betweenness_latency.png){#fig:Betweenness_Latency
width="5.7in"}

![Betweenness centrality
map($C^B$)](Img/result_map_betweenness_capacity.png){#fig:Betweenness_Capacity
width="5.7in"}

![Betweenness centrality
map($C^C$)](Img/result_map_betweenness_cost.png){#fig:Betweenness_Cost
width="5.7in"}

Figure [5.21](#fig:Betweenness_Aggregate){reference-type="ref"
reference="fig:Betweenness_Aggregate"} aggregates the betweenness
results above to provide a summary of the node distribution to the
adjacent cables. Of the three classes of routing policies, each group is
showing a different focus on patterns. It is crucial to use various
distance metrics over the entire STC network to demonstrate the function
of betweenness centralities.

Out of 3 routing policies, the spatial pattern reveals some informative
clues. Firstly the latency betweenness measure of $C^L$ appears to
maintain one highlighted connection between two geographic adjacent
continents, especially in the route connecting from Singapore(Asia) to
New York (North America) via UK(Europe). This outcome may have been
influenced by the demand in the finance sector(eg Stock exchange), as
the data synchronization between financial data centers usually consists
of the feature of high requirements for real-time transmission.
Secondary, the bandwidth betweenness shows a widespread distribution,
this offers many benefits from reliability to data accessibility. This
distributed architecture might not propose a critical bandwidth shortage
problem to the remaining servers even if the malfunction occurs on the
most important node(eg India). As some of the web-services services can
be hosted on the existing cloud or CDN deployments, the widespread wide
bandwidth cables are most clearly benefiting from the cloud-hosted
resources(eg. trending YouTube videos) on the nearby CDN service
stations. Finally, the cost betweenness highlights the necessary nodes
required to achieve the minimum cost, showcase route from Singapore to
Brazil via India, UAE and South Africa is highlighted, while this route
avoids the most cable congested water lane in the Mediterranean Sea
instead of an open connection in South Africa. It is interesting to find
out the overlap between $C^B$ and $C^C$ in East Africa where the
cables(eg 2Africa) are more advanced in budget control and bandwidth
capacity.

![Aggregated betweenness centrality
map](Img/result_map_betweenness_aggregated.png){#fig:Betweenness_Aggregate
width="5.7in"}

Figure [5.21](#fig:Betweenness_Aggregate){reference-type="ref"
reference="fig:Betweenness_Aggregate"} aggregates the previous
betweenness analysis into one visualization to provide a snapshot of the
top 5% most important routes around the world. With a high clustering in
Southeast Asia, MENA(Middle East and North Africa) and Celtic Sea, this
finding could be utilized to simulate the consequence of the cable
accident in those regions by estimating the impact on overall network
functionality reduction.

## Network optimization with CPP

The Tonga volcano eruption on 20 Dec 2021 was reportedly the greatest
volcanic explosion to have occurred since 1883 on record, which
subsequently caused the destruction of Tonga only STC on 15th Jan.
[@cnn_2022_tonga]

After 38 days of lack of full access to broadband, repair ship Reliance
replaced 92km of STC between Tonga to Fiji. [@tom_2022_internet]
Satellite telecommunication was used to support communication with the
outside world during that period, however the traffic shrank by around
99%.

![Tonga internet traffic during the STC
failure[@cloudflare_2022_internet]](Img/result_img_tongaTraffic.png){#fig:Tonga_Traffic
width="5.7in"}

### Redundancy analysis

Building multiple cables as backup internet services will help Tonga
overcome the fault scenario and mitigate the consequences of
connectivity loss on the primary cable. This acquires at least two
cables, whether they are STC or TTC, connecting to the same landing
station. On this basis,  the author uses the Chinese Postman Problem
(CPP) for network improvement. According to the CPP's theory, edges can
be classified as either in-degree or out-degree, and each node contains
at least one pair of each type of edge. Out of many solutions, we found
an optimal solution by minimizing the total length of the additional
route planned to be built.

![Planned STC optimization for
Tonga](Img/result_map_OptTonga_route.png){#fig:Opt_TongaCable
width="5.7in"}

This modification to the STCs would make the network more efficient by
allowing more nodes to participate in the information transformation,
the average degree centrality was increased from 0.0588 to 0.0660
locally in these regions. On another positive note, network becomes more
distributed by reducing the dependency on essential communication
between the high degree nodes. According to the analysis in Figure
[5.24](#fig:Tonga_RichClub){reference-type="ref"
reference="fig:Tonga_RichClub"}, the average rich-club coefficient is
now 0.2660 compared to 0.2741 before to the improvement, indicating a
weaker rich-club effect in the optimized design as the degree different
is smaller.

![Rich-club analysis in
Tonga](Img/result_line_OptTonga_RichCompare.png){#fig:Tonga_RichClub
width="5.7in"}

### Financial cost

Any modification to the existing system could bring extra cost,
especially when laying the additional cables for extra redundancy. The
cost of deploying extra STC and the implementation of start link as an
alternative technology in the Tonga region will be compared and
contrasted in this section.

While analyzing the cost of the existing cables in the near water
against with cable attributes by regression analysis, an adjusted
R-squared of 0.963 suggests a good fit to the budget estimation of the
planned cables. The expected lengths of the two cables from Tonga to
Niue and American Samoa are 618.18KM and 517.63KM with the cost of
\$13.29 and \$10.54 Million USD separately. These cables will directly
benefit people in Tonga, Niue, and American Samoa. They also offer a
sub-optimal route for nearby countries such as French Polynesia and Cook
Islands.

![Estimate cost to deploy redundant
cables](Img/result_map_OptTonga_cost.png){#fig:Tonga_NewCable_Cost
width="5.7in"}

With 25 years of industrial average service life, the infrastructure
life expectancy will be based on that. Star link is the most common
consumer level satellite internet services, as an alternative technology
to the STC. Hardware (\$599) and services (\$110/Month), which together
make up the price to use the Start Link [@starlink_2022_starlink], can
be estimated to reach \$112 per capita during the following 25 years.
Meanwhile, the STC is sharing the same infrastructure cost regardless of
the number of internet users, the capita cost is inversely proportional
to the number of subscribed users to the network. As Figure
[5.26](#fig:TongaCable_cost){reference-type="ref"
reference="fig:TongaCable_cost"} shows, by the estimate from ITU in 2016
there are 55612 internet users in Tonga, Niue and American Samoa, it
would be more cost-effective to invest in STC if more than 1862 units
(individuals or companies) are willing to pay for the most standard data
package in the next 25 years.

![Cost of new STC compared with alternative
technology](Img/result_line_OptTonga_costCompare.png){#fig:TongaCable_cost
width="5.7in"}

# Discussion {#sec:Disscussion}

This paper studies the topological structure of the STC network and
analyzes its vulnerability at both country level and route level. This
section aims to comment on the findings and reflect on the limitations
due to their real-world implications.

Firstly, the country level network consists of a wider range of areas by
averaging the geographical differences and accessibility to the cable
repair resources. For instance, different water conditions measurements,
waterway and no-shipping zone, rich and poor countries. A more explicit
analysis would help to clarify the damage results. Secondary, landlocked
states are not included in this study, this was partly because of the
lack of construction data in TTC. Consequently, the international
bandwidth purely flowing through the TTC network is ignored. Thirdly,
the property status for some STCs are not publicly available. The
estimation was based on the cable length, year of construction, budget
cost and the status of existing cables in the nearby water. The actual
capacity in usage is less than estimation since the most cited metrics
are potential capacity(max possible bandwidth) rather than lit
capacity(actual running bandwidth).

As the STC network's topological structure is the main focus. Testing
results of the shortest-path analysis from UK to China and global
betweenness centrality analysis using different distance measurements to
simulate the assortment of focus on the routing strategies. The shortest
path finding merely discloses some theoretical paths, the routers in the
real-world also need to consider factors such as instantaneous
availability of the cables, communication jamming and pre-defined rules
in the routing table etc. The overlap of a handful of landing stations
with the high value of betweenness centrality also suggests the
potential risk of workload overwhelming on the popular landing stations
when they are chosen by multiple routing policies simultaneously.

However, STC failure could also be dependent on a variety of regional
circumstances. Future research will examine the role of CDN, high
volumes of fishing, cargo shipping, water saltiness, and earth tectonic
hazard frequency. This study was motivated by the analysis of the route
pattern in the real-world distribution when the weakness of STC can be
targeted, the identification of adjustments for the quality
infrastructure setup through avoidance of the missing connections. Yet,
these arguments do not go far enough.

To overcome the vulnerability, redundancy is not the only available
option to fill the missing capacity gap due to the absence of a primary
cable. Instead, redundant cables are especially weak against human-led
destruction. States can influence the cable deploying companies with a
more frequent cable status patrol or by adding prevent cautions such as
setting up cable protection zones to prevent the damage from fishing
dredge or anchoring. Yet these precautions do not exclude the risk of
natural hazards. Avoiding the seismic, volcanic, and landslide zone on
the cable path is meaningful to prevent destruction from the geologic
activities before laying the cables. Thus the open communication and
negotiation between ISPs and cable operators before the proper
deployment helps to reduce the uncertainty of the network stability.

Another aspect that also helps to better understand the vulnerability is
the countermeasures in the internet backbone landing stations while
facing major events such as unexpected hostile attacks on infrastructure
or internet blackouts due to a natural hazard. Moreover, the dependency
on energy infrastructure and cascading effects on the bandwidth
deteriorates in the nearby states, along with the negative side effects
on other internet-dependent businesses such as government
administration, banking services and other digital services. Leading to
a higher requirement for cable and relative infrastructure protection.

Additionally, developing emergency planning and keeping open
communication with the damage control crew and in-hand repair
tools(materials, vessels) are the keys to maintaining broadband
connectivity. Moreover, the satellite internet communication devices
also help to enhance the robustness against STC failure. In view of
this, installing the redundant cables and utilizing satellite internet
services as the backup technology by driving the diversification of the
broadband access entrance can be considered a bright side to the global
internet connectivity resilience.

# Conclusion and Recommendations {#sec:Conclusion}

The submarine telecommunication cable network is an essential
infrastructure that urgently needs to be protected, but academia and
international legislation should not dismiss the negative social and
economical tensions caused by STC failure, especially when the
intentional attack(eg military and terrorism) can be achieved very
easily.

This paper modeled the global STC network and analyzed the topological
vulnerabilities from 2 arguments(cable, landing station) in 2 visibility
levels(country, local) as the means of assessing the robustness of
alternative cables when the primary fails.

The study firstly analysis all the states(n=183) with STC connections,
the broadband threshold of internet shortage in the next few years
remains low, but around 48% of the countries are formed in the most
vulnerable class. The most vulnerable states must improve their
telecommunication infrastructure quality to minimize the probability of
internet blackout at the state level. Also, a further territorial
investigation shows the high dependency of a handful of key landing
stations on international internet connectivity. In addition, we also
compared the impact of emerging internet services
infrastructure(star-link), their usage as an emergency substitute, which
might back up the additional connectivity. From the standpoint of cable
shortages in internet vulnerable countries and the increasing
participation of international tech giants recently, future research
will also take into consideration larger international geopolitical
contestation.

However, these findings need to be seen in context of certain
limitations. There are deviations from real observations for nations
with domestically abundant internet content resources, like the US; or
that have adopted the same language as sizable proportion of internet
users, such as China. Consequently, the estimation in the model could
result in excessive or inadequate network flows. On the other hand,
modeling the local accessibility of internet connectivity goes beyond
the network's topological structure and may also take
local/international legislation and marine sciences into account.

Due to the short duration of the project lifecycle, the model will be
expanded to include GraphEmbedding and representation learning in future
research. Exploring the role that CDN can play in mitigating the
consequences while facing the major STC disruptions or internet peak
hours.

As data communication plays a crucial role more than ever, the
importance and vulnerability of the STC should seriously be recognized
by relative experts from oceanography to geopolitics.

# Appendix

## Country level network visualization

![Country level network
visualization](Img/appendix_img_countryEdges.png){#fig:countryEdges
width="5.7in"}

## Landing station level network visualization

![Landing station level network
visualization](Img/appendix_img_landingEdges.png){#fig:landingEdges
width="5.7in"}

## Country's first STC

::: longtable
\|l\|l\|

\
&\

**Table  -- continued from previous page**\
&\

\

Denmark & 1989\
Sweden & 1989\
United Kingdom & 1989\
Isle of Man & 1990\
Spain & 1990\
Poland & 1991\
Estonia & 1992\
Finland & 1992\
France & 1992\
Iran & 1992\
United Arab Emirates & 1992\
United States & 1992\
Cyprus & 1993\
Turkey & 1993\
Croatia & 1994\
Djibouti & 1994\
Faroe Islands & 1994\
Germany & 1994\
Guernsey & 1994\
Iceland & 1994\
Italy & 1994\
Jersey & 1994\
Latvia & 1994\
Morocco & 1994\
Yemen & 1994\
Anguilla & 1995\
Antigua & Barbuda & 1995\
Argentina & 1995\
Australia & 1995\
Barbados & 1995\
Dominica & 1995\
Greece & 1995\
Grenada & 1995\
Guadeloupe & 1995\
Lebanon & 1995\
Lithuania & 1995\
Malta & 1995\
Martinique & 1995\
Monaco & 1995\
Saint Kitts & Nevis & 1995\
Saint Lucia & 1995\
Saint Vincent & Grenadines & 1995\
Sint Maarten & 1995\
Syria & 1995\
Trinidad & Tobago & 1995\
Tunisia & 1995\
Uruguay & 1995\
Virgin Islands (U.K.) & 1995\
Albania & 1996\
Brazil & 1996\
Portugal & 1996\
Bahamas & 1997\
Bulgaria & 1997\
Cape Verde & 1997\
Cayman Islands & 1997\
Main land, China & 1997\
Colombia & 1997\
Dominican Republic & 1997\
Egypt & 1997\
India & 1997\
Jamaica & 1997\
Japan & 1997\
Jordan & 1997\
Malaysia & 1997\
Netherlands & 1997\
Northern Mariana Islands & 1997\
Philippines & 1997\
Romania & 1997\
Saudi Arabia & 1997\
South Korea & 1997\
Thailand & 1997\
Virgin Islands (U.S.) & 1997\
Bahrain & 1998\
Kuwait & 1998\
Libya & 1998\
Qatar & 1998\
Venezuela & 1998\
Aruba & 1999\
Belgium & 1999\
Brunei & 1999\
Curacao & 1999\
Indonesia & 1999\
Ireland & 1999\
Israel & 1999\
Myanmar & 1999\
Norway & 1999\
Oman & 1999\
Pakistan & 1999\
Singapore & 1999\
Sri Lanka & 1999\
Taiwan, China & 1999\
Vietnam & 1999\
Bermuda & 2000\
Chile & 2000\
Costa Rica & 2000\
Fiji & 2000\
French Guiana & 2000\
Georgia & 2000\
Honduras & 2000\
Mexico & 2000\
New Zealand & 2000\
Panama & 2000\
Peru & 2000\
Russia & 2000\
Belize & 2001\
Canada & 2001\
Ecuador & 2001\
Guatemala & 2001\
Nicaragua & 2001\
Turks and Caicos Islands & 2001\
Algeria & 2002\
Angola & 2002\
Benin & 2002\
Cameroon & 2002\
Cote D'Ivoire & 2002\
Gabon & 2002\
Ghana & 2002\
Mauritius & 2002\
Nigeria & 2002\
Reunion & 2002\
Senegal & 2002\
South Africa & 2002\
Sudan & 2003\
Saint Martin & 2004\
Bangladesh & 2005\
Haiti & 2006\
Iraq & 2006\
Maldives & 2006\
Montserrat & 2006\
Saint Barthelemy & 2006\
Bonaire, Sint Eustatius and Saba & 2007\
New Caledonia & 2008\
American Samoa & 2009\
Greenland & 2009\
Kenya & 2009\
Madagascar & 2009\
Mozambique & 2009\
Papua New Guinea & 2009\
Samoa & 2009\
Tanzania & 2009\
Comoros & 2010\
French Polynesia & 2010\
Guyana & 2010\
Marshall Islands & 2010\
Micronesia & 2010\
Somalia & 2010\
Suriname & 2010\
Equatorial Guinea & 2011\
Gibraltar & 2011\
Congo, Dem. Rep. & 2012\
Congo, Rep. & 2012\
Cuba & 2012\
Gambia & 2012\
Guinea & 2012\
Guinea-Bissau & 2012\
Liberia & 2012\
Mauritania & 2012\
Mayotte & 2012\
Namibia & 2012\
Sao Tome & Principe & 2012\
Seychelles & 2012\
Sierra Leone & 2012\
Togo & 2012\
Tonga & 2013\
Ukraine & 2014\
Vanuatu & 2014\
Cambodia & 2017\
Palau & 2017\
Christmas Island & 2018\
Saint Pierre and Miquelon & 2018\
Wallis and Futuna & 2018\
Cook Islands & 2020\
Niue & 2020\
Solomon Islands & 2020\
Azerbaijan & 2022\
Cocos (Keeling) Islands & 2022\
Kazakhstan & 2022\
Kiribati & 2022\
Saint Helena & 2022\
Tokelau & 2022\
Turkmenistan & 2022\
Timor-Leste & 2024
:::

## Country's cable connection

::: longtable
\|l\|l\|l\|l\|

\
& & &\

**Table  -- continued from previous page**\
& & &\

\

Albania & Croatia & 1 & 0.0006\
Albania & Italy & 1 & 0.0025\
Algeria & France & 4 & 510.8073\
Algeria & Spain & 2 & 40.16\
American Samoa & Samoa & 1 & 2.4915\
Angola & Brazil & 1 & 40\
Angola & Cameroon & 2 & 15.3\
Angola & Italy & 1 & 140.4585\
Anguilla & Virgin Islands (U.K.) & 1 & 1.1\
Antigua & Barbuda & Montserrat & 1 & 1.0501\
Antigua & Barbuda & Saint Kitts & Nevis & 1 & 1.1\
Argentina & Dominican Republic & 1 & 19.2\
Argentina & United States & 1 & 140.4585\
Argentina & Venezuela & 1 & 4.84\
Aruba & Colombia & 1 & 45\
Australia & Cocos (Keeling) Islands & 1 & 39\
Australia & Indonesia & 3 & 336\
Australia & Japan & 2 & 25.7399\
Australia & Papua New Guinea & 2 & 28.4\
Australia & Timor-Leste & 1 & 187.338\
Australia & United States & 5 & 198.28\
Bahamas & Panama & 1 & 8.4\
Bahrain & Kuwait & 4 & 194.2385\
Bahrain & Saudi Arabia & 1 & 1.28\
Bangladesh & Sri Lanka & 3 & 269.3584\
Barbados & Saint Lucia & 2 & 2.1501\
Belgium & France & 1 & 0.1399\
Belgium & United Kingdom & 4 & 105.6925\
Belize & Guatemala & 1 & 8.4\
Benin & France & 1 & 20\
Benin & Ghana & 1 & 0.8\
Benin & Togo & 1 & 78.9573\
Bermuda & United States & 2 & 2.82\
Bermuda & Venezuela & 1 & 0.1865\
Brazil & Argentina & 3 & 102.9973\
Brazil & Bermuda & 1 & 0.1865\
Brazil & Dominican Republic & 1 & 50\
Brazil & Trinidad & Tobago & 1 & 10\
Brazil & United States & 3 & 292\
Brazil & Uruguay & 2 & 230.4585\
Brunei & Indonesia & 1 & 0.1399\
Brunei & Malaysia & 1 & 24.9506\
Brunei & Singapore & 1 & 28\
Brunei & Vietnam & 1 & 28.8\
Cambodia & Malaysia & 2 & 110\
Cameroon & Brazil & 1 & 32\
Cameroon & Equatorial Guinea & 1 & 24\
Cameroon & Gabon & 2 & 20.8\
Cameroon & Nigeria & 2 & 27.3\
Canada & United States & 3 & 128.584\
Cape Verde & Brazil & 1 & 72\
Cayman Islands & Costa Rica & 1 & 0.9225\
Cayman Islands & Honduras & 1 & 140.4585\
Chile & Colombia & 2 & 24.04\
Chile & Peru & 1 & 108\
Chile & United States & 1 & 72\
Main land, China & Brunei & 3 & 56.9399\
Main land, China & Malaysia & 1 & 0.5\
Main land, China & Singapore & 3 & 70.96\
Main land, China & United States & 2 & 105.6\
Main land, China & Vietnam & 5 & 421.84\
Christmas Island & Singapore & 1 & 60\
Cocos (Keeling) Islands & Oman & 1 & 39\
Colombia & Jamaica & 1 & 12.8\
Colombia & United States & 9 & 289.0075\
Comoros & Djibouti & 2 & 152.2585\
Congo, Dem. Rep. & Congo, Rep. & 2 & 154.9585\
Congo, Rep. & Angola & 2 & 154.9585\
Cook Islands & Niue & 1 & 10\
Costa Rica & Honduras & 1 & 0.9225\
Costa Rica & Mexico & 1 & 3.2\
Costa Rica & Nicaragua & 1 & 8.4\
Croatia & Italy & 1 & 0.0331\
Cyprus & Egypt & 3 & 48.72\
Cyprus & Greece & 1 & 187.338\
Cyprus & Italy & 1 & 0.0025\
Cyprus & Turkey & 4 & 42.9968\
Denmark & Faroe Islands & 1 & 0.0075\
Denmark & Iceland & 1 & 5.1\
Denmark & Netherlands & 1 & 44.385\
Denmark & Norway & 4 & 2095.025\
Denmark & United Kingdom & 1 & 105.3101\
Djibouti & Cyprus & 1 & 0.1399\
Djibouti & Egypt & 5 & 591.2641\
Djibouti & Jordan & 1 & 187.338\
Djibouti & Kenya & 3 & 244\
Djibouti & Tanzania & 3 & 159.5385\
Djibouti & Turkey & 1 & 18.7069\
Dominica & Trinidad & Tobago & 2 & 2.1501\
Dominican Republic & Chile & 1 & 19.2\
Dominican Republic & Colombia & 1 & 50\
Dominican Republic & Haiti & 1 & 7.2\
Dominican Republic & Jamaica & 1 & 2.5\
Dominican Republic & Turks and Caicos Islands & 1 & 8.4\
Dominican Republic & United States & 2 & 140.5371\
Ecuador & Guatemala & 2 & 127.2\
Ecuador & Panama & 2 & 185.4585\
Egypt & Algeria & 1 & 30\
Egypt & France & 3 & 444.5841\
Egypt & Greece & 4 & 760.1399\
Egypt & Italy & 5 & 80.8773\
Egypt & Libya & 1 & 3.84\
Egypt & Malta & 1 & 16\
Egypt & South Africa & 2 & 147.7385\
Equatorial Guinea & Nigeria & 1 & 20\
Equatorial Guinea & Sao Tome & Principe & 1 & 105.3101\
Estonia & Sweden & 2 & 0.2307\
Faroe Islands & Iceland & 2 & 0.0275\
Fiji & New Caledonia & 1 & 105.3101\
Fiji & New Zealand & 2 & 94\
Fiji & Samoa & 1 & 17.6\
Fiji & Tonga & 1 & 7.8844\
Fiji & Vanuatu & 1 & 0.32\
Finland & Estonia & 4 & 0.4248\
Finland & Germany & 1 & 144\
Finland & Sweden & 5 & 44.549\
France & Ghana & 1 & 20\
France & Jersey & 1 & 0.5903\
France & Morocco & 1 & 1.4006\
France & Spain & 1 & 480\
France & United Kingdom & 8 & 2655.0382\
France & United States & 1 & 250\
French Polynesia & Cook Islands & 1 & 10\
Gabon & Benin & 1 & 78.9573\
Gabon & Equatorial Guinea & 1 & 20\
Gabon & Nigeria & 2 & 141.2585\
Gambia & Senegal & 1 & 20\
Georgia & Bulgaria & 1 & 12.6\
Georgia & Russia & 1 & 0.0025\
Germany & Denmark & 5 & 1.4331\
Germany & Netherlands & 1 & 5.2\
Ghana & Portugal & 1 & 10\
Ghana & Spain & 4 & 175.7585\
Gibraltar & Portugal & 1 & 3.84\
Greece & Albania & 1 & 0.0006\
Greece & Italy & 9 & 1346.4782\
Greece & Libya & 1 & 1.2\
Greenland & Canada & 1 & 2.56\
Grenada & Antigua & Barbuda & 2 & 2.1501\
Guatemala & Mexico & 3 & 198.8585\
Guinea & Guinea-Bissau & 1 & 20\
Guinea-Bissau & Mauritania & 1 & 20\
Guyana & Barbados & 1 & 44.385\
Guyana & Trinidad & Tobago & 2 & 188.618\
Haiti & Bahamas & 1 & 1.0501\
Haiti & Jamaica & 1 & 7.2\
Honduras & Belize & 1 & 8.4\
Honduras & Guatemala & 1 & 140.4585\
Honduras & Mexico & 1 & 0.9225\
Iceland & Greenland & 1 & 2.56\
India & Maldives & 3 & 452.4241\
India & Mauritius & 1 & 0.44\
India & Oman & 5 & 497.378\
India & Pakistan & 5 & 224.7087\
India & Saudi Arabia & 1 & 7.28\
India & United Arab Emirates & 1 & 0.5\
Indonesia & Christmas Island & 1 & 60\
Indonesia & Malaysia & 6 & 82.7576\
Indonesia & Singapore & 17 & 1088.356\
Indonesia & United States & 1 & 24.9506\
Indonesia & Vietnam & 1 & 0.1399\
Iran & Bahrain & 2 & 53.76\
Iran & Kuwait & 1 & 0.0025\
Iraq & Comoros & 1 & 140.4585\
Iraq & Yemen & 1 & 2.56\
Ireland & Canada & 2 & 78\
Ireland & Iceland & 1 & 18\
Ireland & United States & 2 & 137.199\
Isle of Man & Ireland & 1 & 105.3101\
Israel & Cyprus & 4 & 231.6519\
Israel & Italy & 1 & 12.8\
Italy & Algeria & 1 & 480\
Italy & Belgium & 1 & 0.1399\
Italy & France & 4 & 289.368\
Italy & Gabon & 1 & 140.4585\
Italy & Monaco & 1 & 0.0006\
Italy & Tunisia & 4 & 28.4315\
Italy & United Kingdom & 1 & 0.5\
Jamaica & Cayman Islands & 1 & 8.4\
Jamaica & Cuba & 1 & 5.12\
Jamaica & United States & 1 & 12.8\
Japan & Canada & 1 & 105.3101\
Japan & Philippines & 4 & 242.559\
Japan & Russia & 2 & 1.28\
Japan & South Korea & 10 & 388.7199\
Japan & Taiwan, China & 2 & 247.338\
Japan & United States & 7 & 224.2199\
Jersey & Guernsey & 2 & 0.6234\
Jordan & Egypt & 2 & 0.6049\
Jordan & Israel & 1 & 187.338\
Kazakhstan & Azerbaijan & 1 & 105.3101\
Kenya & Cyprus & 1 & 16\
Kenya & Egypt & 1 & 192\
Kenya & Mozambique & 3 & 159.5385\
Kiribati & Australia & 1 & 72\
Kuwait & Madagascar & 1 & 140.4585\
Kuwait & Saudi Arabia & 2 & 53.76\
Latvia & Sweden & 2 & 0.0356\
Lebanon & Cyprus & 1 & 0.0006\
Lebanon & Egypt & 1 & 3.323\
Liberia & Sierra Leone & 1 & 20\
Libya & Italy & 1 & 0.12\
Libya & Monaco & 1 & 3.84\
Lithuania & Latvia & 1 & 0.0442\
Lithuania & Sweden & 2 & 18.7855\
Madagascar & Saudi Arabia & 1 & 140.4585\
Madagascar & Somalia & 1 & 11.8\
Madagascar & South Africa & 1 & 24\
Malaysia & Bangladesh & 1 & 249.8641\
Malaysia & India & 1 & 0.44\
Malaysia & Myanmar & 2 & 258.7069\
Malaysia & Sri Lanka & 1 & 55\
Malaysia & Thailand & 8 & 394.2272\
Maldives & Oman & 1 & 2.56\
Maldives & Pakistan & 1 & 249.8641\
Malta & France & 1 & 16\
Malta & Italy & 5 & 16.5782\
Marshall Islands & Micronesia & 1 & 3.323\
Mauritania & Gambia & 1 & 20\
Mauritius & Madagascar & 2 & 25.28\
Mauritius & South Africa & 1 & 0.44\
Micronesia & Palau & 1 & 24.9506\
Micronesia & United States & 1 & 3.323\
Monaco & United Kingdom & 1 & 3.84\
Montserrat & Saint Kitts & Nevis & 1 & 1.0501\
Morocco & Portugal & 2 & 480.1399\
Mozambique & Egypt & 1 & 7.28\
Mozambique & Sudan & 2 & 152.2585\
Myanmar & Bangladesh & 1 & 18.7069\
Myanmar & India & 2 & 320\
Myanmar & Sri Lanka & 1 & 0.1399\
Namibia & Congo, Dem. Rep. & 1 & 14.5\
Namibia & Nigeria & 1 & 12\
Netherlands & Belgium & 2 & 105.3126\
Netherlands & United Kingdom & 6 & 4084.3937\
New Caledonia & Australia & 1 & 0.64\
New Zealand & Australia & 4 & 349\
New Zealand & Kiribati & 1 & 72\
Nicaragua & Honduras & 1 & 8.4\
Nigeria & Benin & 1 & 0.8\
Nigeria & France & 1 & 140.4585\
Nigeria & Ghana & 1 & 10\
Nigeria & Saint Helena & 1 & 12\
Nigeria & Sao Tome & Principe & 1 & 20\
Nigeria & Togo & 1 & 14.5\
Nigeria & United Kingdom & 1 & 2.5\
Niue & Samoa & 1 & 10\
Northern Mariana Islands & United States & 2 & 7.2786\
Norway & Canada & 1 & 187.338\
Norway & Ireland & 2 & 309.0631\
Norway & United Kingdom & 2 & 216.1399\
Oman & Iran & 2 & 13.7958\
Oman & Saudi Arabia & 3 & 444.898\
Oman & Seychelles & 1 & 140.4585\
Oman & Somalia & 1 & 24.9506\
Oman & United Arab Emirates & 9 & 214.0068\
Pakistan & Oman & 5 & 240.5853\
Pakistan & Saudi Arabia & 1 & 249.8641\
Pakistan & Seychelles & 1 & 16\
Pakistan & United Arab Emirates & 3 & 196.1103\
Palau & Indonesia & 1 & 144\
Palau & Philippines & 1 & 24.9506\
Panama & Cayman Islands & 2 & 141.381\
Panama & Costa Rica & 2 & 11.6\
Panama & Mexico & 1 & 20\
Papua New Guinea & Indonesia & 1 & 44.385\
Papua New Guinea & United States & 1 & 8.4\
Peru & Ecuador & 2 & 127.2\
Peru & Panama & 1 & 4.84\
Philippines & Main land, China & 8 & 271.7399\
Philippines & Indonesia & 3 & 399.6266\
Philippines & United States & 3 & 269.8192\
Poland & Denmark & 1 & 0.0025\
Poland & Sweden & 1 & 0.005\
Portugal & Cape Verde & 2 & 86.5\
Portugal & Liberia & 1 & 20\
Portugal & Senegal & 3 & 151.2585\
Qatar & Bahrain & 3 & 141.7585\
Qatar & Iran & 2 & 53.76\
Qatar & Saudi Arabia & 1 & 80\
Romania & Bulgaria & 1 & 0.0012\
Russia & Finland & 1 & 0.1865\
Russia & Ukraine & 1 & 10.5159\
Saint Helena & Portugal & 1 & 12\
Saint Kitts & Nevis & Saint Martin & 2 & 8.9345\
Saint Kitts & Nevis & Sint Maarten & 1 & 1.1\
Saint Lucia & Saint Vincent & Grenadines & 2 & 2.1501\
Saint Martin & United States & 3 & 6.0526\
Saint Pierre and Miquelon & Canada & 1 & 33.2781\
Saint Vincent & Grenadines & Dominica & 2 & 2.1501\
Saint Vincent & Grenadines & Grenada & 1 & 44.385\
Samoa & Wallis and Futuna & 1 & 17.6\
Sao Tome & Principe & Benin & 1 & 20\
Saudi Arabia & Djibouti & 7 & 706.022\
Saudi Arabia & Egypt & 1 & 0.7873\
Saudi Arabia & Iraq & 2 & 53.76\
Saudi Arabia & Jordan & 1 & 0.5\
Saudi Arabia & Lebanon & 1 & 3.323\
Saudi Arabia & Somalia & 2 & 332.4585\
Saudi Arabia & Sudan & 2 & 5.7121\
Saudi Arabia & Yemen & 2 & 98.7069\
Senegal & Cape Verde & 1 & 16\
Seychelles & Somalia & 1 & 16\
Seychelles & Tanzania & 1 & 5.9114\
Seychelles & United Arab Emirates & 1 & 140.4585\
Sierra Leone & Guinea & 1 & 20\
Singapore & India & 2 & 89.12\
Singapore & Malaysia & 11 & 866.5363\
Singapore & Myanmar & 1 & 140.4585\
Singapore & Thailand & 3 & 284.03\
Singapore & United States & 5 & 946.0141\
Sint Maarten & Anguilla & 1 & 1.1\
Sint Maarten & Saint Martin & 1 & 0.0025\
Solomon Islands & Australia & 1 & 20\
Somalia & Comoros & 1 & 11.8\
Somalia & Djibouti & 2 & 52\
Somalia & Iraq & 1 & 140.4585\
Somalia & Yemen & 1 & 192\
South Africa & Angola & 1 & 0.8\
South Africa & Cameroon & 1 & 20\
South Africa & Congo, Dem. Rep. & 1 & 140.4585\
South Africa & Namibia & 2 & 26.5\
South Korea & Main land, China & 1 & 0.5\
South Korea & Taiwan, China & 8 & 359.4199\
Spain & Morocco & 3 & 485.1237\
Spain & Portugal & 5 & 179.5985\
Spain & United States & 2 & 305.3101\
Sri Lanka & India & 7 & 509.3113\
Sri Lanka & Maldives & 2 & 80.3578\
Sri Lanka & Pakistan & 1 & 18.7069\
Sudan & Egypt & 2 & 143.0185\
Sudan & South Africa & 1 & 11.8\
Suriname & Guyana & 2 & 188.618\
Sweden & Denmark & 12 & 15.3295\
Syria & Cyprus & 1 & 0.0006\
Syria & Egypt & 1 & 0.005\
Syria & Lebanon & 1 & 0.0786\
Taiwan, China & Main land, China & 7 & 315.9914\
Taiwan, China & Philippines & 5 & 348.388\
Taiwan, China & United States & 1 & 60\
Tanzania & Kenya & 3 & 159.5385\
Thailand & Bangladesh & 1 & 0.7873\
Thailand & India & 1 & 0.5\
Thailand & Myanmar & 2 & 80.1399\
Thailand & Sri Lanka & 1 & 200\
Thailand & United States & 1 & 28.8\
Timor-Leste & Indonesia & 1 & 187.338\
Togo & Ghana & 1 & 14.5\
Togo & Morocco & 1 & 78.9573\
Trinidad & Tobago & Grenada & 2 & 2.1501\
Trinidad & Tobago & Venezuela & 1 & 10\
Tunisia & Algeria & 1 & 0.7873\
Turkey & Egypt & 2 & 18.8468\
Turkey & Greece & 1 & 38.4\
Turkey & Romania & 1 & 0.0012\
Turkmenistan & Azerbaijan & 1 & 105.3101\
Turks and Caicos Islands & Colombia & 1 & 8.4\
United Arab Emirates & Iran & 1 & 0.0186\
United Arab Emirates & Kenya & 1 & 1.28\
United Arab Emirates & Qatar & 7 & 275.5385\
United Arab Emirates & Saudi Arabia & 7 & 219.2971\
United Kingdom & Faroe Islands & 2 & 0.59\
United Kingdom & Ghana & 2 & 142.9585\
United Kingdom & Gibraltar & 1 & 3.84\
United Kingdom & Guernsey & 3 & 5.1705\
United Kingdom & Ireland & 11 & 135.8518\
United Kingdom & Isle of Man & 5 & 106.7584\
United Kingdom & Jersey & 1 & 0.0002\
United Kingdom & Morocco & 1 & 0.1399\
United Kingdom & Spain & 3 & 109.6501\
United Kingdom & United States & 6 & 166.3865\
United States & American Samoa & 1 & 67\
United States & Bahamas & 3 & 22.8\
United States & Cuba & 2 & 63.0919\
United States & Ecuador & 2 & 185.4585\
United States & French Polynesia & 1 & 0.64\
United States & Guatemala & 1 & 50\
United States & Mexico & 1 & 105.3101\
United States & Panama & 4 & 96.1225\
United States & Peru & 2 & 24.04\
United States & Tokelau & 1 & 72\
Uruguay & Argentina & 4 & 234.8912\
Venezuela & Chile & 1 & 4.84\
Venezuela & Colombia & 1 & 0.1865\
Venezuela & Dominican Republic & 1 & 8.4\
Venezuela & Jamaica & 1 & 5.12\
Venezuela & United States & 1 & 10\
Vietnam & Cambodia & 1 & 80\
Vietnam & Singapore & 6 & 370.7799\
Virgin Islands (U.K.) & Aruba & 1 & 45\
Virgin Islands (U.K.) & Bermuda & 1 & 2.5\
Virgin Islands (U.K.) & Dominican Republic & 1 & 2.5\
Virgin Islands (U.S.) & Dominican Republic & 1 & 140.4585\
Virgin Islands (U.S.) & United States & 1 & 0.0786\
Yemen & Djibouti & 4 & 290.7401\
Yemen & Sudan & 1 & 2.56
:::

## STC vulnerable countries

::: longtable
\|l\|l\|l\|

\
& &\

**Table  -- continued from previous page**\
& &\

\

Romania & Europe & 0.0012\
Albania & Europe & 0.0031\
Syria & Asia & 0.0056\
Poland & Europe & 0.0075\
Croatia & Europe & 0.0338\
Latvia & Europe & 0.0798\
Vanuatu & Oceania & 0.32\
Faroe Islands & Europe & 0.5975\
Jersey & Europe & 0.6234\
Haiti & North America & 1.0501\
Montserrat & North America & 1.0501\
Anguilla & North America & 1.1\
Sint Maarten & North America & 1.1025\
Antigua & Barbuda & North America & 2.1501\
Dominica & North America & 2.1501\
Saint Lucia & North America & 2.1501\
Marshall Islands & Oceania & 3.323\
Lebanon & Asia & 3.4023\
Gibraltar & Europe & 3.84\
Monaco & Europe & 3.8406\
Northern Mariana Islands & Oceania & 7.2786\
Greenland & North America & 7.36\
Nicaragua & North America & 8.4\
Turks and Caicos Islands & North America & 8.4\
Bonaire, Sint Eustatius and Saba & North America & 9.285\
Costa Rica & North America & 9.3225\
Cook Islands & Oceania & 10\
Niue & Oceania & 10\
Saint Kitts & Nevis & North America & 10.0345\
Ukraine & Europe & 10.5159\
Bahamas & North America & 11.8501\
Saint Helena & Africa & 12\
Bulgaria & Europe & 12.6012\
Georgia & Asia & 12.6025\
Saint Barthelemy & North America & 12.8844\
Saint Martin & North America & 12.8869\
Wallis and Futuna & Oceania & 17.6\
Lithuania & Europe & 18.8297\
Gambia & Africa & 20\
Guinea & Africa & 20\
Guinea-Bissau & Africa & 20\
Liberia & Africa & 20\
Mauritania & Africa & 20\
Solomon Islands & Oceania & 20\
Sierra Leone & Africa & 20\
Mayotte & Africa & 23.9869\
Reunion & Africa & 25.72\
Namibia & Africa & 26.5\
Samoa & Oceania & 30.0915\
Saint Pierre and Miquelon & North America & 33.2781\
Belize & North America & 33.3506\
Cocos (Keeling) Islands & Asia & 39\
Aruba & North America & 45.1\
Barbados & North America & 46.5351\
Grenada & North America & 46.5351\
Saint Vincent & Grenadines & North America & 46.5351\
Tonga & Oceania & 47.8844\
Christmas Island & Asia & 60\
Guadeloupe & North America & 65.299\
Cuba & North America & 68.2119\
American Samoa & Oceania & 69.4915\
Kiribati & Oceania & 72\
Tokelau & Oceania & 72\
Micronesia & Oceania & 72.6586\
Cambodia & Asia & 80\
Togo & Africa & 93.4573\
Benin & Africa & 99.7573\
Azerbaijan & Asia & 105.3101\
Kazakhstan & Asia & 105.3101\
Turkmenistan & Asia & 105.3101\
Belgium & Europe & 105.5526\
New Caledonia & Oceania & 105.9501\
Sao Tome & Principe & Africa & 125.3101\
Virgin Islands (U.S.) & North America & 140.5371\
Honduras & North America & 149.781\
Cayman Islands & North America & 149.781\
Congo, Dem. Rep. & Africa & 154.9585\
Congo, Rep. & Africa & 154.9585\
Mozambique & Africa & 159.5385\
Seychelles & Africa & 162.3699\
Palau & Oceania & 168.9506\
Timor-Leste & Asia & 187.338\
Jordan & Asia & 187.9429\
Suriname & South America & 188.618\
Iraq & Asia & 194.2185\
French Guiana & South America & 207.338\
Guyana & South America & 233.003\
Bangladesh & Asia & 269.3584
:::

## STC robust countries

::: longtable
\|l\|l\|l\|l\|l\|l\|

\
& & & & &\

**Table  -- continued from previous page**\
& & & & &\

\

Estonia & Europe & 0.2639 & 0.1865 & 0.0442 & 0.0331\
Bermuda & North America & 5.32 & 2.5 & 2.5 & 0.32\
Guernsey & Europe & 5.7583 & 3.3 & 1.868 & 0.5903\
Libya & Africa & 8.363 & 3.84 & 3.323 & 1.2\
Martinique & North America & 21.1 & 10 & 10 & 1.1\
Iceland & Europe & 23.12 & 18 & 5.1 & 0.02\
Venezuela & South America & 23.52 & 10 & 8.4 & 5.12\
Tunisia & Africa & 28.3873 & 18 & 9.6 & 0.7873\
Jamaica & North America & 28.4 & 12.8 & 8.4 & 7.2\
Mauritius & Africa & 33.28 & 24 & 8 & 1.28\
Virgin Islands (U.K.) & North America & 50 & 45 & 2.5 & 2.5\
Turkey & Asia & 61.539 & 38.4 & 18.7069 & 4.4321\
Iran & Asia & 61.6444 & 51.2 & 7.8844 & 2.56\
Curacao & North America & 63.4 & 45 & 10 & 8.4\
Sweden & Europe & 67.524 & 44.385 & 18.7069 & 4.4321\
Papua New Guinea & Oceania & 74.9009 & 44.385 & 20 & 10.5159\
Cameroon & Africa & 76 & 32 & 24 & 20\
Brunei & Asia & 81.7506 & 28.8 & 28 & 24.9506\
Malta & Europe & 89.2247 & 59.199 & 16 & 14.0257\
Cape Verde & Africa & 102.5 & 72 & 16 & 14.5\
Isle of Man & Europe & 106.7293 & 105.3101 & 1.4006 & 0.0186\
Fiji & Oceania & 144.9101 & 105.3101 & 22 & 17.6\
Germany & Europe & 150.2501 & 144 & 5.2 & 1.0501\
Sudan & Africa & 156.6906 & 140.4585 & 11.8 & 4.4321\
Tanzania & Africa & 159.5385 & 140.4585 & 11.8 & 7.28\
French Polynesia & Oceania & 160.4585 & 140.4585 & 10 & 10\
Ghana & Africa & 162.9585 & 140.4585 & 20 & 2.5\
Comoros & Africa & 163.1654 & 140.4585 & 18.7069 & 4\
Nigeria & Africa & 173.2585 & 140.4585 & 20 & 12.8\
Madagascar & Africa & 176.2585 & 140.4585 & 24 & 11.8\
Senegal & Africa & 176.4585 & 140.4585 & 20 & 16\
South Africa & Africa & 184.4585 & 140.4585 & 24 & 20\
Peru & South America & 186.399 & 108 & 59.199 & 19.2\
Finland & Europe & 188.5715 & 144 & 44.385 & 0.1865\
Kenya & Africa & 192.4585 & 140.4585 & 36 & 16\
Bahrain & Asia & 194.2185 & 140.4585 & 51.2 & 2.56\
Kuwait & Asia & 194.2185 & 140.4585 & 51.2 & 2.56\
Angola & Africa & 194.9585 & 140.4585 & 40 & 14.5\
Dominican Republic & North America & 198.8585 & 140.4585 & 50 & 8.4\
Chile & South America & 199.2 & 108 & 72 & 19.2\
Somalia & Africa & 201.409 & 140.4585 & 36 & 24.9506\
Trinidad & Tobago & North America & 204.538 & 187.338 & 10 & 7.2\
Denmark & Europe & 208.8941 & 105.3101 & 59.199 & 44.385\
Russia & Asia & 227.3422 & 104 & 78.9573 & 44.385\
Netherlands & Europe & 228.6524 & 105.3101 & 78.9573 & 44.385\
Uruguay & South America & 234.8906 & 140.4585 & 90 & 4.4321\
Colombia & South America & 235.4585 & 140.4585 & 50 & 45\
Israel & Asia & 238.538 & 187.338 & 38.4 & 12.8\
Cote D'Ivoire & Africa & 239.4157 & 140.4585 & 78.9573 & 20\
Gabon & Africa & 239.4157 & 140.4585 & 78.9573 & 20\
Cyprus & Asia & 241.738 & 187.338 & 38.4 & 16\
Panama & North America & 257.4585 & 140.4585 & 72 & 45\
Equatorial Guinea & Africa & 269.7686 & 140.4585 & 105.3101 & 24\
Qatar & Asia & 271.6585 & 140.4585 & 80 & 51.2\
Vietnam & Asia & 274 & 140 & 80 & 54\
United Arab Emirates & Asia & 275.4585 & 140.4585 & 80 & 55\
South Korea & Asia & 278 & 144 & 80 & 54\
Yemen & Asia & 290.7069 & 192 & 80 & 18.7069\
Ecuador & South America & 293.4585 & 140.4585 & 108 & 45\
Mexico & North America & 295.7686 & 140.4585 & 105.3101 & 50\
Guatemala & North America & 298.4585 & 140.4585 & 108 & 50\
Main land, China & Asia & 300 & 140 & 80 & 80\
Argentina & South America & 309.4157 & 140.4585 & 90 & 78.9573\
Myanmar & Asia & 338.7069 & 240 & 80 & 18.7069\
Brazil & South America & 372.4585 & 160 & 140.4585 & 72\
Taiwan, China & Asia & 372.6481 & 187.338 & 105.3101 & 80\
New Zealand & Oceania & 379 & 240 & 72 & 67\
Canada & North America & 386.9955 & 187.338 & 140.4585 & 59.199\
Philippines & Asia & 406.2953 & 187.338 & 140 & 78.9573\
Thailand & Asia & 420 & 200 & 140 & 80\
Oman & Asia & 420.4585 & 200 & 140.4585 & 80\
Ireland & Europe & 433.1742 & 249.8641 & 105.3101 & 78\
Japan & Asia & 467.7965 & 187.338 & 140.4585 & 140\
Pakistan & Asia & 470.3226 & 249.8641 & 140.4585 & 80\
Maldives & Asia & 528.8214 & 249.8641 & 200 & 78.9573\
Sri Lanka & Asia & 528.8214 & 249.8641 & 200 & 78.9573\
Malaysia & Asia & 529.8641 & 249.8641 & 200 & 80\
Algeria & Africa & 550 & 480 & 40 & 30\
Morocco & Africa & 564.0773 & 480 & 78.9573 & 5.12\
Australia & Oceania & 567.7965 & 240 & 187.338 & 140.4585\
Indonesia & Asia & 567.7965 & 240 & 187.338 & 140.4585\
Singapore & Asia & 571.338 & 240 & 187.338 & 144\
Egypt & Africa & 590.3226 & 249.8641 & 200 & 140.4585\
Saudi Arabia & Asia & 590.3226 & 249.8641 & 200 & 140.4585\
Djibouti & Africa & 590.3226 & 249.8641 & 200 & 140.4585\
India & Asia & 590.3226 & 249.8641 & 200 & 140.4585\
Greece & Europe & 627.338 & 360 & 187.338 & 80\
Norway & Europe & 653.2022 & 249.8641 & 216 & 187.338\
United States & North America & 677.338 & 250 & 240 & 187.338\
Italy & Europe & 687.7965 & 360 & 187.338 & 140.4585\
Portugal & Europe & 692.4585 & 480 & 140.4585 & 72\
Spain & Europe & 1140 & 480 & 460 & 200\
United Kingdom & Europe & 2604.4585 & 2400 & 140.4585 & 64\
France & Europe & 2837.2022 & 2400 & 249.8641 & 187.338
:::

## Country degree centrality

::: longtable
\|l\|l\|l\|

\
& &\

**Table  -- continued from previous page**\
& &\

\

India & Asia & 0.4635\
Singapore & Asia & 0.4325\
Japan & Asia & 0.3696\
Saudi Arabia & Asia & 0.2289\
Brazil & South America & 0.2164\
United States & Central America & 0.1946\
France & Europe & 0.1905\
Indonesia & Asia & 0.1626\
United Arab Emirates & Asia & 0.1562\
Pakistan & Asia & 0.0894\
Egypt & Africa & 0.0843\
United Kingdom & Europe & 0.0741\
Italy & Europe & 0.0696\
South Korea & Asia & 0.0638\
Main land, China & Asia & 0.0525\
Oman & Asia & 0.0428\
Taiwan, China & Asia & 0.0402\
Nigeria & Africa & 0.0381\
Colombia & South America & 0.0335\
Greece & Europe & 0.0283\
Kenya & Africa & 0.026\
Bahamas & North America & 0.0222\
Cyprus & Europe & 0.0219\
Qatar & Asia & 0.0214\
Cape Verde & Africa & 0.0214\
Malaysia & Asia & 0.0204\
Philippines & Asia & 0.0195\
Spain & Europe & 0.019\
Mexico & Central America & 0.019\
Portugal & Europe & 0.0161\
Fiji & Australia & 0.0161\
Maldives & Asia & 0.0159\
Australia & Australia & 0.0144\
Kuwait & Asia & 0.0107\
Israel & Asia & 0.0107\
Dominican Republic & North America & 0.0103\
Somalia & Africa & 0.01\
Cameroon & Africa & 0.0095\
Guatemala & Central America & 0.0089\
Bahrain & Asia & 0.0089\
Sri Lanka & Asia & 0.008\
Sudan & Africa & 0.0074\
Saint Vincent & Grenadines & Central America & 0.0073\
Tanzania & Africa & 0.0071\
Venezuela & South America & 0.0058\
Jamaica & North America & 0.0058\
Papua New Guinea & Australia & 0.0058\
Denmark & Europe & 0.0046\
Ireland & Europe & 0.0043\
Honduras & Central America & 0.0042\
Belgium & Europe & 0.004\
Libya & Africa & 0.0034\
Trinidad & Tobago & North America & 0.0027\
Benin & Africa & 0.0027\
Grenada & North America & 0.0025\
New Zealand & Australia & 0.0025\
Panama & Central America & 0.0024\
Saint Martin & North America & 0.0024\
Morocco & Africa & 0.0022\
South Africa & Africa & 0.0019\
Angola & Africa & 0.0019\
Sao Tome & Principe & Africa & 0.0018\
New Caledonia & Australia & 0.0018\
Comoros & Africa & 0.0018\
Iraq & Asia & 0.0018\
Djibouti & Africa & 0.0018\
Albania & Europe & 0.0018\
Cayman Islands & North America & 0.0016\
Greenland & Central America & 0.0016\
Uruguay & South America & 0.0015\
Turkey & Europe & 0.0015\
Mozambique & Africa & 0.0015\
Iran & Asia & 0.0015\
Equatorial Guinea & Africa & 0.0015\
Syria & Asia & 0.0013\
Solomon Islands & Australia & 0.0013\
Norway & Europe & 0.0013\
Isle of Man & Europe & 0.0013\
Algeria & Africa & 0.0013\
Vietnam & Asia & 0.0012\
Seychelles & Africa & 0.0012\
Palau & Australia & 0.0012\
Cuba & North America & 0.0012\
Republic of Congo & Africa & 0.0012\
Mauritius & Africa & 0.001\
Sint Maarten & North America & 0.0009\
Gibraltar & Europe & 0.0009\
Costa Rica & Central America & 0.0009\
Thailand & Asia & 0.0007\
Iceland & Europe & 0.0007\
Federated States of Micronesia & Australia & 0.0007\
Saint Barthelemy & North America & 0.0007\
Togo & Africa & 0.0006\
Northern Mariana Islands & Australia & 0.0006\
Jordan & Asia & 0.0006\
Democratic Republic of the Congo & Africa & 0.0006\
Bangladesh & Asia & 0.0006\
Antigua & Barbuda & North America & 0.0004\
Netherlands & Europe & 0.0003\
Malta & Europe & 0.0003\
Lebanon & Asia & 0.0003\
Haiti & North America & 0.0003\
Belize & Central America & 0.0003\
Yemen & Asia & 0.0001\
Timor-Leste & Asia & 0.0001\
Suriname & South America & 0.0001\
Romania & Europe & 0.0001\
Madagascar & Africa & 0.0001\
Guinea-Bissau & Africa & 0.0001\
The Gambia & Africa & 0.0001\
Faroe Islands & Europe & 0.0001\
Dominica & North America & 0.0001\
Christmas Island & Australia & 0.0001\
Curaçao & North America & 0.0001\
Cocos Islands & Australia & 0.0001\
Barbados & North America & 0.0001
:::

## LandingPoint degree centrality

::: longtable
\|l\|l\|l\|

\
& &\

**Table  -- continued from previous page**\
& &\

\

Mumbai & India & 0.4284\
Shima & Japan & 0.2529\
Jeddah & Saudi Arabia & 0.2088\
Marseille & France & 0.1895\
Changi North & Singapore & 0.1714\
Tuas & Singapore & 0.1624\
Fujairah & United Arab Emirates & 0.1547\
Fortaleza & Brazil & 0.1487\
Piti & United States & 0.1113\
Changi South & Singapore & 0.0952\
Karachi & Pakistan & 0.0892\
Mazara del Vallo & Italy & 0.0669\
Busan & South Korea & 0.0635\
Rio de Janeiro & Brazil & 0.0595\
Maruyama & Japan & 0.0595\
Suez & Egypt & 0.0589\
Bude & United Kingdom & 0.0571\
Dumai & Indonesia & 0.0521\
Chikura & Japan & 0.0479\
San Juan & United States & 0.0455\
Lagos & Nigeria & 0.0381\
Toucheng & Taiwan, China & 0.0375\
Chennai & India & 0.0333\
Cartagena & Colombia & 0.0292\
Chania & Greece & 0.026\
Mombasa & Kenya & 0.026\
Yeroskipos & Cyprus & 0.0219\
Barka & Oman & 0.0214\
Doha & Qatar & 0.0208\
Cancún & Mexico & 0.0187\
Tanjung Pakis & Indonesia & 0.0178\
Chongming & Main land, China & 0.0178\
Suva & Fiji & 0.0161\
Chung Hom Kok & Main land, China & 0.0156\
Wall Township & United States & 0.0149\
Port Said & Egypt & 0.0143\
Hulhumale & Maldives & 0.0141\
Jakarta & Indonesia & 0.0134\
Praia & Cape Verde & 0.0134\
Medan & Indonesia & 0.0134\
Duba & Saudi Arabia & 0.0112\
Tseung Kwan O & Main land, China & 0.0107\
Tel Aviv & Israel & 0.0107\
Ras Ghareb & Egypt & 0.0107\
Kuwait City & Kuwait & 0.0107\
Isla Verde & United States & 0.0107\
Al Seeb & Oman & 0.0107\
Kribi & Cameroon & 0.0095\
Sesimbra & Portugal & 0.0089\
Puerto Barrios & Guatemala & 0.0089\
Yanbu & Saudi Arabia & 0.0089\
Batam & Indonesia & 0.0083\
Nassau & Bahamas & 0.008\
Port Sudan & Sudan & 0.0074\
Virginia Beach & United States & 0.0071\
Salalah & Oman & 0.0071\
Mogadishu & Somalia & 0.0071\
Melaka & Malaysia & 0.0071\
Dar Es Salaam & Tanzania & 0.0071\
Nanhui & Main land, China & 0.0071\
Punta Cana & Dominican Republic & 0.0067\
Manama & Bahrain & 0.0067\
Kingstown & Saint Vincent & Grenadines & 0.0067\
Perth & Australia & 0.0067\
Southport & United Kingdom & 0.0054\
Matara & Sri Lanka & 0.0054\
Makassar & Indonesia & 0.0054\
Alta Vista & Spain & 0.0054\
Hawksbill & Bahamas & 0.0054\
Santos & Brazil & 0.0052\
Penang & Malaysia & 0.0048\
Okinawa & Japan & 0.0048\
Manado & Indonesia & 0.0048\
Blackpool & United Kingdom & 0.0048\
Sao Pedro & Cape Verde & 0.0045\
Port Moresby & Papua New Guinea & 0.004\
Ostend & Belgium & 0.004\
Morib & Malaysia & 0.004\
Blaabjerg & Denmark & 0.004\
Barranquilla & Colombia & 0.004\
Sydney & Australia & 0.0037\
Timika & Indonesia & 0.0036\
Sorong & Indonesia & 0.0036\
Puerto Plata & Dominican Republic & 0.0036\
Puerto Cortes & Honduras & 0.0036\
Granadilla & Spain & 0.0036\
Dublin & Ireland & 0.0036\
Singapore & Singapore & 0.0036\
Santa Cruz de La Palma & Spain & 0.0027\
Porthcurno & United Kingdom & 0.0027\
Ocho Rios & Jamaica & 0.0027\
Mt. Lavinia & Sri Lanka & 0.0027\
Davao & Philippines & 0.0027\
Cotonou & Benin & 0.0027\
Terempa & Indonesia & 0.0024\
Tanjung Pandan & Indonesia & 0.0024\
Sandy Point & Bahamas & 0.0024\
Roxas City & Philippines & 0.0024\
Punto Fijo & Venezuela & 0.0024\
Point Salines & Grenada & 0.0024\
Pesaren & Indonesia & 0.0024\
Cat Island & Bahamas & 0.0024\
Batu Prahu & Indonesia & 0.0024\
Maria Chiquita & Panama & 0.0022\
Fangshan & Taiwan, China & 0.0022\
Chaguaramas & Trinidad & Tobago & 0.0022\
Amwaj Island & Bahrain & 0.0022\
Whitesands Bay & United Kingdom & 0.0018\
Tarrafal---Santiago & Cape Verde & 0.0018\
Sao Tome & Sao Tome & Principe & 0.0018\
San Jose & Philippines & 0.0018\
Palembang & Indonesia & 0.0018\
Oxford Falls & Australia & 0.0018\
Moroni & Comoros & 0.0018\
Montego Bay & Jamaica & 0.0018\
Kuching & Malaysia & 0.0018\
Haramous & Djibouti & 0.0018\
Graciosa & Portugal & 0.0018\
Genoa & Italy & 0.0018\
Durres & Albania & 0.0018\
Cagayan de Oro & Philippines & 0.0018\
Banjarmasin & Indonesia & 0.0018\
Ancol & Indonesia & 0.0018\
Al Faw & Iraq & 0.0018\
Tétouan & Morocco & 0.0013\
Taytay & Philippines & 0.0013\
Tartous & Syria & 0.0013\
St. Louis & Saint Martin & 0.0013\
Muntok & Indonesia & 0.0013\
Melkbosstrand & South Africa & 0.0013\
Maputo & Mozambique & 0.0013\
Maldonado & Uruguay & 0.0013\
Magen's Bay & United States & 0.0013\
Kristiansand & Norway & 0.0013\
Jacksonville & United States & 0.0013\
Honiara & Solomon Islands & 0.0013\
Bosaso & Somalia & 0.0013\
Bata & Equatorial Guinea & 0.0013\
Athens & Greece & 0.0013\
Anyer & Indonesia & 0.0013\
Victoria & Seychelles & 0.0012\
Sofifi & Indonesia & 0.0012\
Sines & Portugal & 0.0012\
Sangano & Angola & 0.0012\
Sanana & Indonesia & 0.0012\
Quy Nhon & Vietnam & 0.0012\
Qalhat & Oman & 0.0012\
Port Grenaugh & Isle of Man & 0.0012\
Pointe-Noire & Congo, Rep. & 0.0012\
Oran & Algeria & 0.0012\
Noumea & New Caledonia & 0.0012\
Ngeremlengui & Palau & 0.0012\
Muscat & Oman & 0.0012\
Marmaris & Turkey & 0.0012\
Kitaibaraki & Japan & 0.0012\
Kaweni & Mayotte & 0.0012\
Holyhead & United Kingdom & 0.0012\
Highbridge & United Kingdom & 0.0012\
Half Moon Bay & Cayman Islands & 0.0012\
Guantanamo Bay & Cuba & 0.0012\
Governors Harbor & Bahamas & 0.0012\
Funchal & Portugal & 0.0012\
El Goro & Spain & 0.0012\
Dumaguete & Philippines & 0.0012\
Daet & Philippines & 0.0012\
Christchurch & New Zealand & 0.0012\
Brookvale & Australia & 0.0012\
Berbera & Somalia & 0.0012\
Barcelona & Spain & 0.0012\
Baler & Philippines & 0.0012\
Abu Dhabi & United Arab Emirates & 0.0012\
Takesung & Indonesia & 0.0009\
San Sebastian de la Gomera & Spain & 0.0009\
Saint Maarten & Sint Maarten & 0.0009\
Raglan & New Zealand & 0.0009\
Puerto Limon & Costa Rica & 0.0009\
Penmarch & France & 0.0009\
Ormoc & Philippines & 0.0009\
Nuuk & Greenland & 0.0009\
Nabire & Indonesia & 0.0009\
Manokwari & Indonesia & 0.0009\
Madang & Papua New Guinea & 0.0009\
Lingang & Main land, China & 0.0009\
Kuantan & Malaysia & 0.0009\
Khasab & Oman & 0.0009\
Jask & Iran & 0.0009\
Gibraltar & Gibraltar & 0.0009\
Faial & Portugal & 0.0009\
Derna & Libya & 0.0009\
Coron & Philippines & 0.0009\
Candelaria & Spain & 0.0009\
Camuri & Venezuela & 0.0009\
Baie Jacotet & Mauritius & 0.0009\
West Palm Beach & United States & 0.0006\
Tubruq & Libya & 0.0006\
Tual & Indonesia & 0.0006\
Timpaki & Greece & 0.0006\
Tarakan & Indonesia & 0.0006\
Sriracha & Thailand & 0.0006\
Savona & Italy & 0.0006\
Porto Novo---Santo Antao & Cape Verde & 0.0006\
Pohnpei & Micronesia & 0.0006\
North Miami Beach & United States & 0.0006\
Nasugbu & Philippines & 0.0006\
Myrtle Beach & United States & 0.0006\
Muanda & Congo, Dem. Rep. & 0.0006\
Miyazaki & Japan & 0.0006\
Minamiboso & Japan & 0.0006\
Mentigi & Indonesia & 0.0006\
Luwuk & Indonesia & 0.0006\
Luanda & Angola & 0.0006\
Lome & Togo & 0.0006\
Landeyjar & Iceland & 0.0006\
Killala & Ireland & 0.0006\
Kendari & Indonesia & 0.0006\
Kalianda & Indonesia & 0.0006\
Jayapura & Indonesia & 0.0006\
Hithadhoo & Maldives & 0.0006\
Gustavia & Saint Barthelemy & 0.0006\
Estepona & Spain & 0.0006\
Cox's Bazar & Bangladesh & 0.0006\
Conil & Spain & 0.0006\
Chipiona & Spain & 0.0006\
Carcavelos & Portugal & 0.0006\
Banyu Urip & Indonesia & 0.0006\
Bandar Bukit Tinggi & Malaysia & 0.0006\
Asilah & Morocco & 0.0006\
Aqaba & Jordan & 0.0006\
Akita & Japan & 0.0006\
Sidi Kerir & Egypt & 0.0004\
Saint Martin & Saint Martin & 0.0004\
Roxas & Philippines & 0.0004\
Port Blair & India & 0.0004\
Pekanbaru & Indonesia & 0.0004\
Pa Li & Taiwan, China & 0.0004\
Darwin & Australia & 0.0004\
Bull Bay & Jamaica & 0.0004\
Zawia & Libya & 0.0003\
Zahara de los Atunes & Spain & 0.0003\
Yapen & Indonesia & 0.0003\
Wawonii & Indonesia & 0.0003\
Wada & Japan & 0.0003\
Vitória & Brazil & 0.0003\
Vila do Porto & Portugal & 0.0003\
Velas & Portugal & 0.0003\
Valdemar & Denmark & 0.0003\
Tulum & Mexico & 0.0003\
Tuckerton & United States & 0.0003\
Trujillo & Honduras & 0.0003\
Toyohashi & Japan & 0.0003\
Tolmeta & Libya & 0.0003\
Tidore & Indonesia & 0.0003\
Tiakur & Indonesia & 0.0003\
Thinadhoo & Maldives & 0.0003\
Teping Tinggi & Indonesia & 0.0003\
Tebingtinggi Island & Indonesia & 0.0003\
Tarrafal---Sao Nicolau & Cape Verde & 0.0003\
Tanjung Pinggir & Indonesia & 0.0003\
Tanjung Bemban & Indonesia & 0.0003\
Taliabu & Indonesia & 0.0003\
Surabaya & Indonesia & 0.0003\
Supiori & Indonesia & 0.0003\
Suemlaki & Indonesia & 0.0003\
St. John's & Antigua & Barbuda & 0.0003\
São Mateus & Brazil & 0.0003\
Sitio & Brazil & 0.0003\
Sisimiut & Greenland & 0.0003\
Sibolga & Indonesia & 0.0003\
Shindu-Ri & South Korea & 0.0003\
Serwaru & Indonesia & 0.0003\
Sendai & Japan & 0.0003\
Sao Filipe & Cape Verde & 0.0003\
Salakan & Indonesia & 0.0003\
Saint Paul & Reunion & 0.0003\
Rota & Northern Mariana Islands & 0.0003\
Rockly Bay & Trinidad & Tobago & 0.0003\
Rock Sound & Bahamas & 0.0003\
Riohacha & Colombia & 0.0003\
Riding Point & Bahamas & 0.0003\
Recife & Brazil & 0.0003\
Ras Lanuf & Libya & 0.0003\
Rantu Prapat & Indonesia & 0.0003\
Ranai & Indonesia & 0.0003\
Raha & Indonesia & 0.0003\
Puerto Lempira & Honduras & 0.0003\
Puerto La Cruz & Venezuela & 0.0003\
Puerto Cabello & Venezuela & 0.0003\
Porto Seguro & Brazil & 0.0003\
Porlamar & Venezuela & 0.0003\
Pointe-a-Pitre & Guadeloupe & 0.0003\
Pinamalayan & Philippines & 0.0003\
Penarik & Indonesia & 0.0003\
Panipahan & Indonesia & 0.0003\
Padang & Indonesia & 0.0003\
Ozamiz City & Philippines & 0.0003\
Ondong Siau & Indonesia & 0.0003\
Nova Sintra & Cape Verde & 0.0003\
Negril & Jamaica & 0.0003\
Natuna & Indonesia & 0.0003\
Murdeira & Cape Verde & 0.0003\
Morotai & Indonesia & 0.0003\
Morant Point & Jamaica & 0.0003\
Miri & Malaysia & 0.0003\
Milagros & Philippines & 0.0003\
Melonguane & Indonesia & 0.0003\
Mayaguana & Bahamas & 0.0003\
Maracaibo & Venezuela & 0.0003\
Maniitsoq & Greenland & 0.0003\
Macaé & Brazil & 0.0003\
Long Island & India & 0.0003\
Little Andaman & India & 0.0003\
Lisbon & Portugal & 0.0003\
Lingga & Indonesia & 0.0003\
Legazpi City & Philippines & 0.0003\
La Union & Philippines & 0.0003\
Kota Kinabalu & Malaysia & 0.0003\
Kolhufushi & Maldives & 0.0003\
Kokkini & Greece & 0.0003\
Kep. Aru & Indonesia & 0.0003\
Kendal & Indonesia & 0.0003\
Karimun & Indonesia & 0.0003\
Kamorta & India & 0.0003\
João Pessoa & Brazil & 0.0003\
Jambi & Indonesia & 0.0003\
Ilhéus & Brazil & 0.0003\
Igneada & Turkey & 0.0003\
Ibaraki & Japan & 0.0003\
Higuerote & Venezuela & 0.0003\
Havelock & India & 0.0003\
Halul Island & Qatar & 0.0003\
Great Level Bay & Bonaire, Sint Eustatius and Saba & 0.0003\
Great Bay Beach & Saint Martin & 0.0003\
Güimar & Spain & 0.0003\
Gallows Bay & Bonaire, Sint Eustatius and Saba & 0.0003\
Fuvahmulah & Maldives & 0.0003\
Duncan Town & Bahamas & 0.0003\
Diba & Oman & 0.0003\
Dhangethi & Maldives & 0.0003\
Das Island & United Arab Emirates & 0.0003\
Current & Bahamas & 0.0003\
Cumaná & Venezuela & 0.0003\
Crown Haven & Bahamas & 0.0003\
Crooked Island & Bahamas & 0.0003\
Corvo & Portugal & 0.0003\
Coro & Venezuela & 0.0003\
Clarence Town & Bahamas & 0.0003\
Chichiriviche & Venezuela & 0.0003\
Cebu & Philippines & 0.0003\
Cayman Brac & Cayman Islands & 0.0003\
Caves Point & Bahamas & 0.0003\
Cape Town & South Africa & 0.0003\
Butuan City & Philippines & 0.0003\
Brega & Libya & 0.0003\
Boracay & Philippines & 0.0003\
Black River & Jamaica & 0.0003\
Bintulu & Malaysia & 0.0003\
Beverwijk & Netherlands & 0.0003\
Bengkalis & Indonesia & 0.0003\
Benghazi & Libya & 0.0003\
Belize City & Belize & 0.0003\
Baturaja & Indonesia & 0.0003\
Bangga & Indonesia & 0.0003\
Bandar Lampung & Indonesia & 0.0003\
Bandar Abbas & Iran & 0.0003\
Baie Longue & Saint Martin & 0.0003\
Atafona & Brazil & 0.0003\
Aracaju & Brazil & 0.0003\
Angra do Heroismo & Portugal & 0.0003\
Al Daayen & Qatar & 0.0003\
Al Bayda & Libya & 0.0003\
Agats & Indonesia & 0.0003\
Yzerfontein & South Africa & 0.0001\
Yate & New Caledonia & 0.0001\
Wurrumiyanga & Australia & 0.0001\
West Island & Cocos (Keeling) Islands & 0.0001\
Vestmannaeyjar & Iceland & 0.0001\
Vao & New Caledonia & 0.0001\
Vanimo & Papua New Guinea & 0.0001\
Valverde & Spain & 0.0001\
Union Island & Saint Vincent & Grenadines & 0.0001\
Tyra & Denmark & 0.0001\
Trapani & Italy & 0.0001\
Tobelo & Indonesia & 0.0001\
Toamasina & Madagascar & 0.0001\
Tjornuvik & Faroe Islands & 0.0001\
Tjele & Denmark & 0.0001\
Tinocas & Spain & 0.0001\
Ternate & Indonesia & 0.0001\
Teluk & Indonesia & 0.0001\
Tarahales & Spain & 0.0001\
Tanjung Selor & Indonesia & 0.0001\
Takahagi & Japan & 0.0001\
Tadine & New Caledonia & 0.0001\
Suro & Guinea-Bissau & 0.0001\
Sunny Isles & United States & 0.0001\
Sugar Dock & Northern Mariana Islands & 0.0001\
Spanish River Park & United States & 0.0001\
Shanghai & Main land, China & 0.0001\
Sasanlagu & Northern Mariana Islands & 0.0001\
Sarmi & Indonesia & 0.0001\
Sapporo & Japan & 0.0001\
San Remigio & Philippines & 0.0001\
San Jose de Buenavista & Philippines & 0.0001\
Saint Barthelemy & Saint Barthelemy & 0.0001\
Saida & Lebanon & 0.0001\
Roseau & Dominica & 0.0001\
Rome & Italy & 0.0001\
Rayong & Thailand & 0.0001\
Punta del Este & Uruguay & 0.0001\
Port of Spain & Trinidad & Tobago & 0.0001\
Port Erin & Isle of Man & 0.0001\
Port Elizabeth & South Africa & 0.0001\
Port-au-Prince & Haiti & 0.0001\
Playa Blanca & Spain & 0.0001\
Pegwell & Barbados & 0.0001\
Paramaribo & Suriname & 0.0001\
Palma & Spain & 0.0001\
Namlea & Indonesia & 0.0001\
Nador & Morocco & 0.0001\
Nacala & Mozambique & 0.0001\
Mustique & Saint Vincent & Grenadines & 0.0001\
Mont-Dore & New Caledonia & 0.0001\
Mocha & Yemen & 0.0001\
Merauke & Indonesia & 0.0001\
Mellieha & Malta & 0.0001\
Melbourne & Australia & 0.0001\
Masohi & Indonesia & 0.0001\
Maroochydore & Australia & 0.0001\
Mangalia & Romania & 0.0001\
Mahuma & Curacao & 0.0001\
Magachgil & Micronesia & 0.0001\
Madura & Indonesia & 0.0001\
Lorengau & Papua New Guinea & 0.0001\
Lecanvey & Ireland & 0.0001\
Le Porge & France & 0.0001\
Kokopo & Papua New Guinea & 0.0001\
Kismayo & Somalia & 0.0001\
Kimbe & Papua New Guinea & 0.0001\
Kiamsam & Malaysia & 0.0001\
Khark Island & Iran & 0.0001\
Kavieng & Papua New Guinea & 0.0001\
Kaliko & Haiti & 0.0001\
Kaimana & Indonesia & 0.0001\
Jdaide & Lebanon & 0.0001\
Jarry & Guadeloupe & 0.0001\
Invercargill & New Zealand & 0.0001\
Iloilo City & Philippines & 0.0001\
Hobyo & Somalia & 0.0001\
Gwadar & Pakistan & 0.0001\
Great Nicobar & India & 0.0001\
Grand Baie (Rodrigues) & Mauritius & 0.0001\
Gran Canaria & Spain & 0.0001\
George Town & Cayman Islands & 0.0001\
Ganaveh & Iran & 0.0001\
Fukuoka & Japan & 0.0001\
Fresh Creek & Bahamas & 0.0001\
Flying Fish Cove & Christmas Island & 0.0001\
El-Quawef & Libya & 0.0001\
Dunedin & New Zealand & 0.0001\
Dili & Timor-Leste & 0.0001\
Dickenson Bay & Antigua & Barbuda & 0.0001\
Dakhla & Morocco & 0.0001\
Colon & Panama & 0.0001\
Collo & Algeria & 0.0001\
Carriacou & Grenada & 0.0001\
Carúpano & Venezuela & 0.0001\
Cape D'Aguilar & Main land, China & 0.0001\
Canouan & Saint Vincent & Grenadines & 0.0001\
Calbayog & Philippines & 0.0001\
Cadiz City & Philippines & 0.0001\
Cabinda & Angola & 0.0001\
Butterworth & Malaysia & 0.0001\
Buranga & Indonesia & 0.0001\
Brisbane & Australia & 0.0001\
Bintan & Indonesia & 0.0001\
Bequia & Saint Vincent & Grenadines & 0.0001\
Banjul & Gambia & 0.0001\
Balluta Bay & Malta & 0.0001\
Bali & Indonesia & 0.0001\
Auckland & New Zealand & 0.0001\
Arawa & Papua New Guinea & 0.0001\
Annobon & Equatorial Guinea & 0.0001\
Aeng Batu Batu & Indonesia & 0.0001\
Aasiaat & Greenland & 0.0001
:::
