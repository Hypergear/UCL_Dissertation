# Acronyms {#acronyms .unnumbered}

There are some frequent used acronyms for certain items/technologies.

-- Submarine telecommunication cable

-- Terrestrial telecommunication cable

-- Cable landing station

-- Content delivery network

-- Critical infrastructure protection

-- Internet services provider
