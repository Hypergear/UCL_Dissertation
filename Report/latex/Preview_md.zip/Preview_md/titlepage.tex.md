::: titlepage
::: center
**Cornerstone of global communication:\
Vulnerabilities of submarine telecommunication cable from networks\
**

by\

**Zhiheng Jiang\
** **Supervisor: Dr. Sarah Wise\
** **Module ID: CASA0012\
** **Word count: 10968\
** **Aug 2022**

**A Dissertation submitted in part fulfilment of the\
Degree of Master of Science:\
Spatial Data Science and Visualisation\
Centre for Advanced Spatial Analysis\
Bartlett Faculty of the Build Environment\
University College London\
**
:::
:::
