# Abstract {#abstract .unnumbered}

With the rise of global internet connectivity and the increasing
availability of inexpensive computer devices. The submarine
telecommunication cables (STC) play as the backbone infrastructure to
provide the data traffic in the case of international information
transmission. However, STC is extremely vulnerable to damages such as
natural disasters and human-led attacks. If the damage is taken, the
bandwidth deterioration or lagging of the internet services will occur
on end-users' computers. At the core of this paper is a modelling
analysis of the global STC under a topological network structure to
determine the subregional high risk area. As the result, 88 STC
vulnerable countries and an uneven distribution of network dependency
can be located. For a regional STC network system, we proposed a method
to improve and analyze its topological robustness. These findings may
provide some inspiration to the industry and politicians by revisiting
the reliability and vulnerabilities of the STC system under the current
protection measurements.\

**Keywords:** Internet, Telecommunication, Marine infrastructure,
Network science.
