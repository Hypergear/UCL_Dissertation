# Acknowledgement {#acknowledgement .unnumbered}

I would like to thank my supervisor, Dr. Sarah Wise for her patient
guidance throughout the research lifecycle. Her engaged feedbacks and
inspirational research perspectives were not only valuable to this
project, but also improved my level of thinking both academically and
personally. This paper would not be possible without her enthusiastic
support.

This work has also gained vast support from the a various opensource
communities, regardless of open datasets from TeleGeography or python
packages such as NetworkX. Also the useful studies from the research
community. Their humble work makes this research possible.

I am also grateful for the support from my parents and my corgi - Julie,
who have continuously motivated me throughout this study.
