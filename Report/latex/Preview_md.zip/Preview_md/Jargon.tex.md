# Jargon {#jargon .unnumbered}

If you are new to telecommunication industry, learning these jargons
before proceeding is highly recommended

-- The maximum amount of data transmitted over an internet connection in
a given amount of time

-- A process of path selection while transferring data across multiple
network systems.

-- Default referring to potential capacity, the total amount of design
capacity that installed all available equipment at the ends of the
cable.

-- The amount of capacity that is actually running over a cable.
