# This script allows one to load and correct raw files before saving them again.
path_raw      = "../Data/0_raw/"
path_raw_dl   = path_raw+"1_auto_download/"
path_store    = "../Data/1_raw_processed_backup/"
path_live     = "../Data/2_raw_processed_input/"
path_analysis = "../Data/3_analysis/"
path_map      = "../Data/4_mapping_data/"
path_images   = "../Images/"
